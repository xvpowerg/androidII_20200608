package tw.com.xvpower.ch14_2_bindservice;



import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import androidx.annotation.Nullable;

public class MyBindService extends Service {
    private MyBinder myBinder = new MyBinder();
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("Howard","onCreate");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("Howard","onStartCommand");
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("Howard","onDestroy");
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.d("Howard","onUnbind");
        return super.onUnbind(intent);
    }

    @Override
    public void onRebind(Intent intent) {
        Log.d("Howard","onRebind");
        super.onRebind(intent);
    }

    private void showText(String text){
        myBinder.msgTextView.setText(text);
    }

    private class RandomRunnable implements Runnable{
        private int count = 0;
        public RandomRunnable(int count){
            this.count = count;
        }
        @Override
        public void run() {
            for (int i =1;i<=count;i++){
                int rn = ThreadLocalRandom.current().nextInt(50000);
                Log.d("Howard","Thread Name:"+Thread.currentThread().getName());
                myBinder.msgTextView.setText(rn+"");
                try{TimeUnit.SECONDS.sleep(1);}catch(Exception ex){}
            }
        }
    }
    private void startRandom(){
         String numberText =
                 myBinder.numberEditText.getText().toString();
        int count = Integer.parseInt(numberText);
        RandomRunnable rr = new RandomRunnable(count);
        Thread t = new Thread(rr);
        t.start();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.d("Howard","onBind");
        return myBinder;
    }
    public class MyBinder extends Binder {
            public EditText numberEditText;
            public TextView msgTextView;
         public void  showText(String text){
             MyBindService.this.showText(text);
         }
         public void startRandom(){
             MyBindService.this.startRandom();
         }
    }

}

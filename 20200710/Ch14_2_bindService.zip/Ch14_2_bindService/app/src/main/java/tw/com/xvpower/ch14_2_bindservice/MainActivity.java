package tw.com.xvpower.ch14_2_bindservice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    private ServiceConnection serviceConnection;
    private MyBindService.MyBinder myBinder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
           super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView msgInfoText =  findViewById(R.id.msgInfoText);
        EditText countNumber =  findViewById(R.id.countNumber);
        Button bindBtn  =  findViewById(R.id.bindBtn);
        Button stopBtn  =  findViewById(R.id.stopBtn);
       Button invokeBtn =   findViewById(R.id.invokeBtn);

        serviceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                Log.d("Howard","onServiceConnected!!!");
                myBinder = (MyBindService.MyBinder)service;
                myBinder.msgTextView = msgInfoText;
                myBinder.numberEditText = countNumber;
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                Log.d("Howard","onServiceDisconnected!!!");
            }
        };
        //做綁定
       bindBtn.setOnClickListener(v->{
            Intent bindIntent = new Intent(this,MyBindService.class);
            bindService(bindIntent,serviceConnection, Context.BIND_AUTO_CREATE);
        });

       stopBtn.setOnClickListener(v->{
                unbindService(serviceConnection);
        });

        invokeBtn.setOnClickListener(v->{

//            myBinder.showText(countNumber.getText().toString());
            myBinder.startRandom();
        });

    }
}
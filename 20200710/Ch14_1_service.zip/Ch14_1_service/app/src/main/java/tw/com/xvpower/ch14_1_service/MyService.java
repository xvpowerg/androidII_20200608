package tw.com.xvpower.ch14_1_service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.concurrent.TimeUnit;

public class MyService  extends Service {
    private boolean complete = true;
    private boolean canRunThread = true;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("Howard","onCreate");
    }
    private class MyRunnable implements Runnable {
        int countdownNumber = 0;
        MyRunnable(int countdownNumber){
            this.countdownNumber = countdownNumber;
        }
        @Override
        public void run() {
            complete = false;
                for(int i =countdownNumber ;canRunThread && i >=0;i--){
                    Log.d("Howard",i+"");
                    try{
                        TimeUnit.SECONDS.sleep(1);
                    }catch (Exception ex){ }
                }
            complete = true;
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
       int countdown=
               intent.getIntExtra("countdown",-1);
       if (complete && countdown != -1 ){
           MyRunnable myRun = new  MyRunnable(countdown);
           Thread th1 = new Thread(myRun);
           th1.start();
       }
        Log.d("Howard","onStartCommand");
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        canRunThread = false;
        Log.d("Howard","onDestroy");
    }
}

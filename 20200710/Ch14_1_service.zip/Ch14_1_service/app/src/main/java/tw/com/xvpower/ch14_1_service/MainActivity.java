package tw.com.xvpower.ch14_1_service;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import tw.com.xvpower.ch14_1_service.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ActivityMainBinding amb =
                ActivityMainBinding.inflate(getLayoutInflater());
        super.onCreate(savedInstanceState);
        setContentView(amb.getRoot());
        Intent serviceIntent =
                new Intent(this,MyService.class);
        amb.startServiceBtn.setOnClickListener(v->{
            int countdown = Integer.parseInt(amb.countDownNumberEdit.getText().toString());
            serviceIntent.putExtra("countdown",countdown);
            startService(serviceIntent);
        });
        amb.stopServiceBtn.setOnClickListener(v->{
            stopService(serviceIntent);
        });


    }
}
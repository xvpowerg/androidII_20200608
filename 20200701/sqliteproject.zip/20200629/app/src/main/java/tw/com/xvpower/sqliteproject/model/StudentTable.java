package tw.com.xvpower.sqliteproject.model;


import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import tw.com.xvpower.sqliteproject.model.data.Student;
import tw.com.xvpower.sqliteproject.sqlite.DBHelper;

public class StudentTable implements StudentDao {
    public static final String STUDENT_TABLE = "student";
    public static final String C_ID="_id";
    public static final String C_NAME="name";
    public static final String C_SCORE="score";
    public static final String C_CREATE_TIME="create_time";
    private DBHelper dbHelper;
    public StudentTable(DBHelper db){
            this.dbHelper = db;
    }

    public static void create(SQLiteDatabase db) {
        String sql = "CREATE TABLE "+STUDENT_TABLE+ "("+
                "%s INTEGER PRIMARY KEY," +
                "%s TEXT," +
                "%s NUMERIC," +
                "%s TIMESTAMP default CURRENT_TIMESTAMP)";
        sql = String.format(sql,C_ID,C_NAME,C_SCORE,C_CREATE_TIME);
        CreateTable.create(sql,db);
    }

    @Override
    public int  insert(Student st) {
        SQLiteDatabase sd =  dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(C_NAME,st.getName());
        cv.put(C_SCORE,st.getScore());
        long id = sd.insert(STUDENT_TABLE,null,cv);
        st.setId((int)id);
        Log.d("Howard","INSERT .....:"+id);
        return (int)id;
    }

    @Override
    public Student queryById(int id) {
        return null;
    }

    @Override
    public List<Student> queryAll() {
       SQLiteDatabase sb = dbHelper.getReadableDatabase();
       List<Student> list = new ArrayList<>();
       Cursor cursor =
               sb.rawQuery("SELECT * FROM "+STUDENT_TABLE,null);

       while(cursor.moveToNext()){
           int id = cursor.getInt(0);
           String name = cursor.getString(1);
           float score = cursor.getFloat(2);
           Student st = new Student(id,name,score);
           list.add(st);
       }
        return list;
    }

    @Override
    public Student updateById(Student st) {
        return null;
    }

    @Override
    public boolean deleteById(int id) {
            return false;
    }

}

package tw.com.xvpower.sqliteproject.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import tw.com.xvpower.sqliteproject.R;
import tw.com.xvpower.sqliteproject.databinding.RcViewLayoutBinding;
import tw.com.xvpower.sqliteproject.model.data.Student;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.MyViewHolder> {
    private Context context;
    private List<Student> stList;
    private int position = -1;
    public StudentAdapter(Context context,List<Student> stList){
        this.context = context;
        this.stList = stList;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       RcViewLayoutBinding rcv =
        RcViewLayoutBinding.inflate(LayoutInflater.from(context),
                parent,false);
       MyViewHolder  myViewHolder = new MyViewHolder(rcv);

        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Student st = stList.get(position);
        holder.itemView.setOnLongClickListener(v->{
            this.position = holder.getAdapterPosition();
            //false 如果itemView有多個Listener會同時觸發
            //true  如果itemView有多個Listener只會觸發LongClickListener
            return false;
        });
       holder.rcv.nameText.setText(st.getName());
       holder.rcv.scoreText.setText(String.valueOf(st.getScore()));
    }

    @Override
    public int getItemCount() {
        return stList.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder {
        private RcViewLayoutBinding rcv;
        public MyViewHolder(@NonNull RcViewLayoutBinding rcv) {
            super(rcv.getRoot());
            this.rcv = rcv;
        }
    }
}

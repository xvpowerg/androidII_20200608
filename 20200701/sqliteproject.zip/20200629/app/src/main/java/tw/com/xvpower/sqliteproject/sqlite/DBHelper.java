package tw.com.xvpower.sqliteproject.sqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;

import tw.com.xvpower.sqliteproject.model.StudentDao;
import tw.com.xvpower.sqliteproject.model.StudentTable;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "student_db";
    public static final int VERSION = 1;
    private static StudentDao studentDao;
    private static DBHelper dbHelper;
    private Context context;

    public static DBHelper getDBHelper(Context context){
        if (dbHelper == null){
            dbHelper = new DBHelper(context);
        }
        return dbHelper;
    }

    public static StudentDao getStudentDao(Context context){
            if (studentDao == null){
                DBHelper dbh = getDBHelper(context);
                studentDao = new StudentTable(dbh);
            }
         return  studentDao;
    }

     private DBHelper(@Nullable Context context) {
        super(context, DB_NAME, null, VERSION);
        this.context = context;
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        StudentTable.create(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}

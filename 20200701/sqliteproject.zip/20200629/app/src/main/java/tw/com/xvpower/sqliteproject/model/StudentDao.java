package tw.com.xvpower.sqliteproject.model;

import java.util.List;

import tw.com.xvpower.sqliteproject.model.data.Student;

public interface StudentDao {
    void insert(Student st);
    Student queryById(int id);
    List<Student> queryAll();
    Student updateById(Student st);
    boolean deleteById(int id);
}

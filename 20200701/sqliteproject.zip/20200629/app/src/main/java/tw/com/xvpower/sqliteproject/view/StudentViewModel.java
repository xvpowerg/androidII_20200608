package tw.com.xvpower.sqliteproject.view;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;

import tw.com.xvpower.sqliteproject.model.StudentDao;
import tw.com.xvpower.sqliteproject.model.StudentTable;
import tw.com.xvpower.sqliteproject.model.data.Student;
import tw.com.xvpower.sqliteproject.sqlite.DBHelper;

//ViewModel 內做作一些修改
//目的 資料庫 跟 Activity完全脫離
public class StudentViewModel {
        private  MyLiveData<List<Student>> listLiveData;
        private Context context;
        public  StudentViewModel(Context context)
        {
            listLiveData = new MyLiveData();
            this.context = context;
        }
      public  StudentViewModel(MyObserver<List<Student>> myObs,Context context){
                listLiveData = new MyLiveData();
                listLiveData.setMyObserver(myObs);
                this.context = context;
        }

        public MyLiveData  getMyLiveData(){
            return listLiveData;
        }
        public  void refresh(){
            StudentDao sdao =  DBHelper.getStudentDao(context);
            List<Student> stList =  sdao.queryAll();
            listLiveData.setValue(stList);
        }
}

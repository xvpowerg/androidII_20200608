package tw.com.xvpower.sqliteproject.view;

import android.content.Context;

import java.util.List;

import tw.com.xvpower.sqliteproject.model.StudentDao;
import tw.com.xvpower.sqliteproject.model.data.Student;
import tw.com.xvpower.sqliteproject.sqlite.DBHelper;

//ViewModel 內做作一些修改
//目的 資料庫 跟 Activity完全脫離
public class StudentViewModel {
        private  MyLiveData<List<Student>> studentsLiveData;
        private Context context;
        public  StudentViewModel(Context context)
        {
            studentsLiveData = new MyLiveData();
            this.context = context;
        }
      public  StudentViewModel(MyObserver<List<Student>> myObs,Context context){
                studentsLiveData = new MyLiveData();
                studentsLiveData.setMyObserver(myObs);
                this.context = context;
        }

        public MyLiveData  getStudentsLiveData(){
            return studentsLiveData;
        }
        public  void refresh(){
            StudentDao sdao =  DBHelper.getStudentDao(context);
            List<Student> stList =  sdao.queryAll();
            studentsLiveData.setValue(stList);
        }
}

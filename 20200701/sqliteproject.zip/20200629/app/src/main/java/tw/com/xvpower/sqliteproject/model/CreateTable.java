package tw.com.xvpower.sqliteproject.model;

import android.database.sqlite.SQLiteDatabase;

public interface CreateTable {
     static void create(String sql, SQLiteDatabase db){
         db.execSQL(sql);
    }
}

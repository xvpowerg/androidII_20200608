package tw.com.xvpower.ch4_20200615_external_file.data;

import java.util.List;

import tw.com.xvpower.ch4_20200615_external_file.bean.Order;

public interface OrderDao {
        int createOrder(Order order);
        List<Order> queryOrders();
        void updateOrder(Order order);
}

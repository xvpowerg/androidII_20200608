package tw.com.xvpower.ch4_20200615_external_file;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;

import tw.com.xvpower.ch4_20200615_external_file.bean.Order;
import tw.com.xvpower.ch4_20200615_external_file.bean.Product;
import tw.com.xvpower.ch4_20200615_external_file.data.json.JsonTools;
import tw.com.xvpower.ch4_20200615_external_file.data.json.OrderJsonData;

public class MainActivity extends AppCompatActivity {


    private void createJson(String json,String name) {
         File  jsonFileDir = getExternalFilesDir("json");
         File jsonFile = new File(jsonFileDir,name);
         Log.d("Howard","File:"+jsonFile.getAbsolutePath());
         try(FileOutputStream fout = new FileOutputStream(jsonFile);
             OutputStreamWriter osw = new OutputStreamWriter(fout)){
             osw.write(json);
         }catch(IOException ex){
            Log.d("Howard","ex:"+ex);
         }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //檢查外部儲存硬體狀態
        String state =  Environment.getExternalStorageState();
        if (state == null ||
                !state.equals(Environment.MEDIA_MOUNTED) ){
            Log.d("Howard","state: Fail");
        }else{
            Log.d("Howard","state: Pass");
        }


        // 轉物件JSON
        Order o1 = new Order();
        Product p1 = new Product();
        p1.setPrice(699);
        p1.setName("PS5");
        Product p2 = new Product();
        p2.setName("iPad Pro");
        p2.setPrice(300);
        o1.setOrderId(10);
        o1.appendProduct(p1);
        o1.appendProduct(p2);

        File  jsonFileDir = getExternalFilesDir("json");
        OrderJsonData orderJsonData=
                OrderJsonData.createOrderJsonData(jsonFileDir);
        orderJsonData.createOrder(o1);

//        ArrayList<Order> orderList = new ArrayList();
//        orderList.add(o1);
//        Gson gson = new GsonBuilder().create();
//        String json = gson.toJson(orderList);
//        Log.d("Howard","Json:"+json);
//        createJson(json,"order.json");
//
//
//        //JSON 轉物件
//        Type type =   new TypeToken<ArrayList<Order>>(){}.getType();
//        ArrayList<Order> orders =   gson.fromJson(json,type);
//        Log.d("Howard","order:"+orders.get(0).getOrderId());


    }
}
package tw.com.xvpower.ch4_20200615_external_file.data.json;

import android.util.Log;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import tw.com.xvpower.ch4_20200615_external_file.bean.Order;
import tw.com.xvpower.ch4_20200615_external_file.data.OrderDao;

public class OrderJsonData implements OrderDao {
    private String jsonName = "order.json";
    private File jsonFile;
    public static OrderJsonData createOrderJsonData(
            File jsonDirFile){
          return new OrderJsonData(jsonDirFile);
    }
     OrderJsonData(File jsonDirFile){
        this.jsonFile = new File(jsonDirFile,jsonName);
    }

    public int createOrder(Order order) {

        //要先查出Json 轉換為List
        String json= JsonTools.readJson(jsonFile);
        ArrayList<Order> orderList = new ArrayList<>();
        if (json != null && json.length() >1){
            orderList = JsonTools.jsonToObj(json);
        }
        orderList.add(order);
        //將order 寫入 List
        //再將List轉為Json 之前的Json覆蓋檔案
        json = JsonTools.objToJson(orderList);
        Log.d("Howard","Create json:"+json);
        //String json = "";
        JsonTools.createJson(jsonFile,json);
        return 0;
    }

    @Override
    public List<Order> queryOrders() {
        return null;
    }

    @Override
    public void updateOrder(Order order) {

    }
}

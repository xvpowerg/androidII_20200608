package tw.com.xvpower.ch4_20200615_external_file.bean;

public class SerialNumber {

    private synchronized static int getSerial(){

        return 0;
    }
}

package tw.com.xvpower.ch7_3_loader;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;

public class MainActivity extends AppCompatActivity implements
        LoaderManager.LoaderCallbacks<Cursor>{
    private LoaderManager loaderManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        loaderManager = LoaderManager.getInstance(this);
        loaderManager.initLoader(1,null,this);
    }
    @NonNull
    @Override
    public Loader<Cursor> onCreateLoader(int id, @Nullable Bundle args) {
        final String DB_NAME = "coffee_5000.db";
        final File dbFile = new File(getFilesDir(),DB_NAME) ;
        final String dbPath = dbFile.getAbsolutePath();
        Log.d("Howard","dbFile Path:"+dbPath);
        MyCursorLoader myCursorLoader = new MyCursorLoader(this,dbPath);
        return myCursorLoader;
    }

    @Override
    public void onLoadFinished(@NonNull Loader<Cursor> loader, Cursor data) {
            Log.d("Howard","onLoadFinished Count:"+data.getCount());
    }

    @Override
    public void onLoaderReset(@NonNull Loader<Cursor> loader) {

    }
}
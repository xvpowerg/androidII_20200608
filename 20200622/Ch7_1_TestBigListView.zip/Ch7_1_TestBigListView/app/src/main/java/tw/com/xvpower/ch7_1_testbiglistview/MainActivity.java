package tw.com.xvpower.ch7_1_testbiglistview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        int[] images = {R.drawable.ic_baseline_account_box_24,
        R.drawable.ic_baseline_alarm_24,
                R.drawable.ic_baseline_beach_access_24};
      ListView listView =  findViewById(R.id.listView);
      List<TestObject> testObjList = new ArrayList<>();
        for (int i=1;i<=50000;i++){
            TestObject tobj = new TestObject(
                    i+"",i*2+"",
                    i*3+"",i*4+"",
                    images[i % images.length]);
            testObjList.add(tobj);
        }
        MyAdapter adapter = new MyAdapter(this,testObjList);
        listView.setAdapter(adapter);
    }
}
package tw.com.xvpower.ch7_1_testbiglistview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MyAdapter extends BaseAdapter {
    private List<TestObject> testObjList = new ArrayList<>();
    private Context context;
    public MyAdapter(Context context,List<TestObject> testObjList){
        this.context = context;
        this.testObjList = testObjList;
    }
    @Override
    public int getCount() {
        return testObjList.size();
    }

    @Override
    public TestObject getItem(int position) {
        return testObjList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        TestObject tobj =  this.getItem(position);
       View view =  LayoutInflater.from(context).
               inflate(R.layout.list_layout,
                parent,false);
        TextView t1 =  view.findViewById(R.id.itemText1);
        TextView t2 =  view.findViewById(R.id.itemText2);
        TextView t3 =  view.findViewById(R.id.itemText3);
        TextView t4 =  view.findViewById(R.id.itemText4);
        ImageView image =  view.findViewById(R.id.imageView);
        t1.setText(tobj.getItemText1());
        t2.setText(tobj.getItemText2());
        t3.setText(tobj.getItemText3());
        t4.setText(tobj.getItemText4());
        image.setImageResource(tobj.getImageId());
        return view;
    }
}

package tw.com.xvpower.ch7_2_recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        int[] images = {R.drawable.ic_baseline_account_box_24,
                R.drawable.ic_baseline_alarm_24,
                R.drawable.ic_baseline_beach_access_24};
        List<TestObject> testObjList = new ArrayList<>();
        RecyclerView rcv =  findViewById(R.id.recyclerView);
       // rcv.setLayoutManager(new LinearLayoutManager(this));
        rcv.setLayoutManager(new GridLayoutManager(this,
                        3));
        for (int i=1;i<=50000;i++){
            TestObject tobj = new TestObject(
                    i+"",i*2+"",
                    i*3+"",i*4+"",
                    images[i % images.length]);
            testObjList.add(tobj);
        }
        MyAdapter myAdapter = new MyAdapter(this,testObjList);
        rcv.setAdapter(myAdapter);
    }
}
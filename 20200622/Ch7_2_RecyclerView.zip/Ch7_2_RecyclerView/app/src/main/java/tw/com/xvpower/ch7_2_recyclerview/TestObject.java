package tw.com.xvpower.ch7_2_recyclerview;

public class TestObject {
    String itemText1,itemText2,itemText3,itemText4;
    int imageId;

    public TestObject(String itemText1, String itemText2,
                      String itemText3, String itemText4, int imageId) {
        this.itemText1 = itemText1;
        this.itemText2 = itemText2;
        this.itemText3 = itemText3;
        this.itemText4 = itemText4;
        this.imageId = imageId;
    }

    public String getItemText1() {
        return itemText1;
    }

    public void setItemText1(String itemText1) {
        this.itemText1 = itemText1;
    }

    public String getItemText2() {
        return itemText2;
    }

    public void setItemText2(String itemText2) {
        this.itemText2 = itemText2;
    }

    public String getItemText3() {
        return itemText3;
    }

    public void setItemText3(String itemText3) {
        this.itemText3 = itemText3;
    }

    public String getItemText4() {
        return itemText4;
    }

    public void setItemText4(String itemText4) {
        this.itemText4 = itemText4;
    }

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }
}

package tw.com.xvpower.ch7_2_recyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    class MyViewHolder extends  RecyclerView.ViewHolder{
        private TextView itemText1;
        private TextView itemText2;
        private TextView itemText3;
        private TextView itemText4;
        private ImageView imageView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
        }

    }
    private List<TestObject> testObjList;
    private Context context;
    MyAdapter(Context context,List<TestObject> testObjList){
            this.context = context;
            this.testObjList = testObjList;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).
                    inflate(R.layout.list_layout,parent,false);
            MyViewHolder mvh = new MyViewHolder(view);
        mvh.itemText1 = view.findViewById(R.id.itemText1);
        mvh.itemText2 = view.findViewById(R.id.itemText2);
        mvh.itemText3 = view.findViewById(R.id.itemText3);
        mvh.itemText4 = view.findViewById(R.id.itemText4);
        mvh.imageView = view.findViewById(R.id.imageView);
        return mvh;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        TestObject tobj =  testObjList.get(position);
        holder.itemText1.setText(tobj.itemText1);
        holder.itemText2.setText(tobj.itemText2);
        holder.itemText3.setText(tobj.itemText3);
        holder.itemText4.setText(tobj.itemText4);
        holder.imageView.setImageResource(tobj.imageId);
    }

    @Override
    public int getItemCount() {
        return testObjList.size();
    }
}

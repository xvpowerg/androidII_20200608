package test.line;

import java.util.concurrent.ExecutionException;

import com.linecorp.bot.client.LineMessagingClient;
import com.linecorp.bot.model.PushMessage;
import com.linecorp.bot.model.message.TextMessage;
import com.linecorp.bot.model.response.BotApiResponse;

public class TestPutLineMessage {
	final static String token = "nGELOGS220nGiGGAPPoMXD9khOfT7Nl3hrL6U5z1UwCNx02KfFjT58ilLyEnnnzXqDkH9C6OFJQ++oUZ3Ww0p6BaSHKbTgYxem2eB3IGCk4tBDNDNISepYCJhI9QnQS4/7s+TminSBujdvHrrZOlywdB04t89/1O/w1cDnyilFU=";	
	final static String userId = "U78b36c53e60c4a2ecfe1d343f448e8b5";
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		// TODO Auto-generated method stub
	LineMessagingClient client = LineMessagingClient.
			builder(token).build();
	TextMessage msg = new TextMessage("�n�f��F!!");
	PushMessage pusMessage = new PushMessage(userId, msg);
	BotApiResponse botApi =   client.pushMessage(pusMessage).get();
	
		
	}

}

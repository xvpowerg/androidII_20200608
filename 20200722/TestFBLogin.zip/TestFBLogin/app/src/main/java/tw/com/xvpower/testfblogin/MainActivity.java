package tw.com.xvpower.testfblogin;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.util.Base64;
import android.util.Log;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.Profile;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;

import java.security.MessageDigest;

public class MainActivity extends AppCompatActivity {
    private CallbackManager callbackManager;
    private void toSHA(){
        PackageInfo info;
        try{

            info= getPackageManager().getPackageInfo(
                    "tw.com.xvpower.testfblogin",
                    PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures){
                MessageDigest md;
                md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                String keyResult = new String(Base64.encode(md.digest(),0));
                Log.d("Howard",keyResult);
            }
        }catch(Exception ex){
            Log.e("Howard","Exception:"+ex);
        }
    }

    private class MyFacebookCallback implements FacebookCallback<LoginResult> {

        @Override
        public void onSuccess(LoginResult loginResult) {
            Log.d("Howard","onSuccess");
        }

        @Override
        public void onCancel() {
            Log.d("Howard","onCancel");
        }

        @Override
        public void onError(FacebookException error) {
            Log.d("Howard","onError");
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       // toSHA();
         LoginButton loginButton =
                 findViewById(R.id.login_button);
        loginButton.setReadPermissions("email");
         callbackManager =
                CallbackManager.Factory.create();
        MyFacebookCallback fc = new MyFacebookCallback();
        loginButton.registerCallback(callbackManager,fc);
    }

    @Override
    protected void onResume() {
        super.onResume();
        ImageView imageView = findViewById(R.id.profile_image);
        //Profile.getCurrentProfile() == null 表示登出
        if (Profile.getCurrentProfile() != null){
            Profile p = Profile.getCurrentProfile();
            Uri userPhoto =  p.getProfilePictureUri(300,300);
            Log.d("Howard","userPhoto:"+userPhoto);
            Glide.with(this).load(userPhoto).into(imageView);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        callbackManager.onActivityResult(requestCode,resultCode,data);
        super.onActivityResult(requestCode, resultCode, data);
    }
}
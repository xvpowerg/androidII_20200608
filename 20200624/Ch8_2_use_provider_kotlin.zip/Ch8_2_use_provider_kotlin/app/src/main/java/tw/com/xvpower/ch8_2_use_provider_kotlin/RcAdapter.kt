package tw.com.xvpower.ch8_2_use_provider_kotlin

import android.database.Cursor
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item_layout.view.*

class RcAdapter(var cursor:Cursor) :RecyclerView.Adapter<RcAdapter.MyViewHolder>()  {
    class MyViewHolder(var view:View):RecyclerView.ViewHolder(view){

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.item_layout,
                parent,false)
        return MyViewHolder(view)
    }

    override fun getItemCount(): Int {
      return cursor.count
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

            if (cursor.moveToPosition(position)){
                  holder.view.idTxt.text =
                      cursor.getInt(0).toString()
                holder.view.titleTxt.text =
                    cursor.getString(1)
                holder.view.priceTxt.text =
                    cursor.getString(2)
            }
    }

}
package tw.com.xvpower.ch8_2_use_provider_kotlin

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    private val myUri =
            Uri.parse("content://tw.com.xvpower.ch7_3_loader.provider.MyProvider")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val cursor = contentResolver.query(myUri, arrayOf("_id","title","price"),
                null,null,null)
        cursor?.run {
            var rcAdapter = RcAdapter(cursor)
            rcList.apply {
                adapter = rcAdapter
                layoutManager = LinearLayoutManager(this@MainActivity)
            }
        }



    }
}
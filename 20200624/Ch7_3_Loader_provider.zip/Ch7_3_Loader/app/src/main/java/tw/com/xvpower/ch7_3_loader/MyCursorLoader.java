package tw.com.xvpower.ch7_3_loader;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.loader.content.CursorLoader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class MyCursorLoader extends CursorLoader {
    private String dbFile ;
    private Context context;
    public MyCursorLoader(@NonNull Context context,String dbFile) {
        super(context);
        this.context = context;
        this.dbFile = dbFile;
    }
    private SQLiteDatabase openDatabase(){
        if (!new File(dbFile).exists()){
            try(InputStream is  =
                        context.getResources().openRawResource(R.raw.coffee_5000);
                FileOutputStream fos = new FileOutputStream(dbFile)){
                byte[] buffer = new byte[1024];
                int index = -1;
                while( (index = is.read(buffer)) >0 ){
                    fos.write(buffer,0,index);
                }
            }catch(IOException ex){
                Log.e("Howard","SQLiteDatabase:"+ex);
            }
        }
        SQLiteDatabase db =
                SQLiteDatabase.openOrCreateDatabase(dbFile,null);
        return db;
    }
    @Nullable
    @Override
    protected Cursor onLoadInBackground() {
         SQLiteDatabase db = openDatabase();
       Cursor cursor =   db.rawQuery("SELECT _id,title,price FROM coffee_list",
                null);
        return cursor;
    }
}

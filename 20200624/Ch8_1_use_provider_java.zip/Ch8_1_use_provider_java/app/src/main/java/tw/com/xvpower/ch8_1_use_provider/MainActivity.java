package tw.com.xvpower.ch8_1_use_provider;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {
    private Uri myUri = Uri.parse("content://tw.com.xvpower.ch7_3_loader.provider.MyProvider");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
     Cursor cursor =    getContentResolver().query(myUri,
                new String[]{"_id","title","price"},null,
                null,null);
        Log.d("Howard","cursor Count:"+cursor.getCount());
    MyCursorAdapter mca = new MyCursorAdapter(cursor);
     RecyclerView rcList =  findViewById(R.id.rcList);
        rcList.setLayoutManager(new LinearLayoutManager(this));
        rcList.setAdapter(mca);
    }
}
package tw.com.xvpower.ch8_sqlite_project.model;

import android.database.sqlite.SQLiteDatabase;

import tw.com.xvpower.ch8_sqlite_project.sqlite.DBHelper;

public class StudentTable implements StudentDao {
    public static final String STUDENT_TABLE = "student";
    private DBHelper db;
    public StudentTable(DBHelper db){
            this.db = db;
    }

    @Override
    public void insert() {

    }

    @Override
    public void queryById() {

    }

    @Override
    public void queryAll() {

    }

    @Override
    public void updateById() {

    }

    @Override
    public void deleteById() {

    }

    @Override
    public void create(SQLiteDatabase db) {
        String sql = "CREATE TABLE "+STUDENT_TABLE+
                "(_id INTEGER PRIMARY KEY," +
                "name TEXT," +
                "score NUMERIC," +
                "create_time TIMESTAMP default CURRENT_TIMESTAMP)";
        db.execSQL(sql);
    }
}

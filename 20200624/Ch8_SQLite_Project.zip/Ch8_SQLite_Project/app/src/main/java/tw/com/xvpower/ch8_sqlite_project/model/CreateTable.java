package tw.com.xvpower.ch8_sqlite_project.model;

import android.database.sqlite.SQLiteDatabase;

public interface CreateTable {
    void create(SQLiteDatabase db);
}

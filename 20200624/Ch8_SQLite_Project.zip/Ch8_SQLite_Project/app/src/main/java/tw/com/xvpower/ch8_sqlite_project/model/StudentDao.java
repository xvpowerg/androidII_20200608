package tw.com.xvpower.ch8_sqlite_project.model;

public interface StudentDao extends  CreateTable {
    void insert();
    void queryById();
    void queryAll();
    void updateById();
    void deleteById();
}

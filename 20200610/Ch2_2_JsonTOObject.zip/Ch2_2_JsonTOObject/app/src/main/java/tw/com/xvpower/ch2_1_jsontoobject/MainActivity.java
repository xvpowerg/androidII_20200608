package tw.com.xvpower.ch2_1_jsontoobject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import tw.com.xvpower.ch2_1_jsontoobject.tools.JsonTools;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onStart() {
        super.onStart();
        String json =
                JsonTools.readJsonForResource(this,R.raw.student);
        JsonTools.jsonStringToStudents(json);
        Log.d("Howard","Json:"+json);
    }
}
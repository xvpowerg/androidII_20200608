package tw.com.xvpower.ch2_1_jsontoobject.tools;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import tw.com.xvpower.ch2_1_jsontoobject.bean.Exam;
import tw.com.xvpower.ch2_1_jsontoobject.bean.Student;

public class JsonTools {

    public static List<Student> jsonStringToStudents(String json){
        ArrayList <Student>list = new ArrayList();
        try{
            JSONArray jsonArray = new JSONArray(json);

            for(int i = 0;i < jsonArray.length();i++){
                JSONObject jobj1 = jsonArray.getJSONObject(i);
                String name = jobj1.getString("name");
                Student st = new Student();
                st.setName(name);
               JSONArray examArray = jobj1.getJSONArray("exam");
               for (int k =0; k <examArray.length();k++){
                   JSONObject examJob= examArray.getJSONObject(k);
                   String subj = examJob.getString("subject");
                   int sc = examJob.getInt("score");
                   Exam exam = new Exam(subj,sc);
                   st.appendExam(exam);
               }
                list.add(st);
            }
        }catch(JSONException ex){
            Log.e("Howard","JSONException:"+ex);
        }

            return list;
    }
    public static String readJsonForResource(Context context,int jsonId){
        StringBuilder json = new StringBuilder();
        try(InputStream is =  context.getResources().openRawResource(jsonId);
            BufferedReader br =
                    new BufferedReader(new InputStreamReader(is))){
            String tmp = null;
            while( (tmp  = br.readLine()) != null) {
                json.append(tmp);
            }
        }catch(IOException ex){
            Log.e("Howard","IOException:"+ex);
        }
        return json.toString();
    }



}

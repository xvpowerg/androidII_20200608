package tw.com.xvpower.ch2_1_jsontoobject.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class Student {
    private String name;
    private List<Exam> examList = new ArrayList<>();
    public void setName(String name){
        this.name = name;
    }
    public void appendExam(Exam ex){
        examList.add(ex);
    }
    public Stream<Exam> getExamStream(){
        return examList.stream();
    }

    public String toString(){
        return name+":"+examList;
    }

}

package tw.com.xvpower.ch2_1_jsontoobject.bean;

public class Exam {
    private String subject;
    private int score;
    public Exam(String subject,int score){
        this.subject = subject;
        this.score = score;
    }
    public String toString(){
        return subject+":"+score;
    }
}

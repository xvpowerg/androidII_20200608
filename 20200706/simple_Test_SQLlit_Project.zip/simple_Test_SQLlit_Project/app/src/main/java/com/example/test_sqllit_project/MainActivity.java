package com.example.test_sqllit_project;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;

import com.example.test_sqllit_project.adapter.StudentAdapter;
import com.example.test_sqllit_project.bean.Student;
import com.example.test_sqllit_project.sqlite.DBHelper;
import com.example.test_sqllit_project.verify.EmptyVerify;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private DBHelper _dbHelper;
    public StudentAdapter _stAdapter;
    private RecyclerView _rcView;
    private AlertDialog alertDialog;
    private  EditText dialogNameET;
    private  EditText dialogScoreET;
    private boolean isUpdata =  false;

    private void initRecyclerView(){
        List<Student> list =   _dbHelper.queryAll();
        _stAdapter = new StudentAdapter(this,list);
        //幫
        DividerItemDecoration itemDecoration =
                new DividerItemDecoration(this,
                        DividerItemDecoration.VERTICAL);
        _rcView.addItemDecoration(itemDecoration);

        _rcView.setLayoutManager(new LinearLayoutManager(this));
        _rcView.setAdapter(_stAdapter);
        //_stAdapter.delete();
    }


    private void alertBtnLinstener(DialogInterface dialog,int which) {
        String name = dialogNameET.getText().toString();
        String score = dialogScoreET.getText().toString();

        boolean test1 = EmptyVerify.testEmpty(name,
                () -> Toast.makeText(this, "姓名不可空白",
                            Toast.LENGTH_SHORT).show());
        boolean test2 = EmptyVerify.testEmpty(score, () ->
                Toast.makeText(this, "成績不可空白", Toast.LENGTH_SHORT).show());

        if (test1 || test2) {
            return;
        }
            if (isUpdata){
                    Student st = _stAdapter.get();
                         st.setName(name);
                        st.setScore(Integer.parseInt(score));
                   if ( _dbHelper.updateById(st)){
                       _stAdapter.update(st);
                   }
                isUpdata = false;
            }else{
                    Student st1 = new Student(name, score);
                    DBHelper.InsertInfo info = _dbHelper.insert(st1);
                    if (info.isPass()) {
                        st1.setId(info.getId());
                        _stAdapter.add(st1);
                    }
            }

    }
    private void initDialog(){
        View dialogView =  getLayoutInflater().inflate(R.layout.dialog_layout,null);
        dialogNameET = dialogView.findViewById(R.id.nameET);
        dialogScoreET = dialogView.findViewById(R.id.scoreET);

        AlertDialog.Builder bu = new AlertDialog.Builder(this).
                setView(dialogView).setNegativeButton("取消",null).
                setPositiveButton("確定",this::alertBtnLinstener).
                setCancelable(false);
        //setPositiveButton andorid.R.id.button1
        alertDialog = bu.create();
    }
    private void showInerDialog(View view){
        dialogNameET.setText("");
        dialogScoreET.setText("");
        alertDialog.show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        _dbHelper = new DBHelper(this);
        _rcView = findViewById(R.id.rcView);
        //初始化Dialog
        initDialog();
        FloatingActionButton fab = findViewById(R.id.fab);
       fab.setOnClickListener(this::showInerDialog);
    }

    @Override
    protected void onResume() {
        super.onResume();
        initRecyclerView();
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
                  Student st =  _stAdapter.get();
                switch (item.getItemId()){
                    case R.id.menu_delete:
                        if (_dbHelper.deleteByID(st))
                               _stAdapter.delete();
                    break;
                    case R.id.menu_update:
                        isUpdata = true;
                        dialogNameET.setText(st.getName());
                        dialogScoreET.setText(st.getScore()+"");
                        alertDialog.show();

                        break;
                }
        return super.onContextItemSelected(item);
    }
}

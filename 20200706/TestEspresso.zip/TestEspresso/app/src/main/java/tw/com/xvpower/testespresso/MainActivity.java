package tw.com.xvpower.testespresso;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import tw.com.xvpower.testespresso.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       ActivityMainBinding amb =
               ActivityMainBinding.inflate(getLayoutInflater());

        amb.calcuBtn.setOnClickListener(v->{
            int n1 =  Integer.parseInt(amb.number1.getText().toString());
            int n2 =  Integer.parseInt(amb.number2.getText().toString());
            int ans = n1 + n2;
            amb.ansText.setText(String.valueOf(ans));
        });
        ArrayAdapter<String> adapter =
                new ArrayAdapter<String>(this,
                        android.R.layout.simple_list_item_1,
                        android.R.id.text1,
                        getResources().getStringArray(R.array.city));
        amb.citySpinner.setAdapter(adapter);
        amb.citySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                  String city =  parent.getAdapter().getItem(position).toString();
                  amb.ansText.setText(city);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        setContentView(amb.getRoot());


    }
}
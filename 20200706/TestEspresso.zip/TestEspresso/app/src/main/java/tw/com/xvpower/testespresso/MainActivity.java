package tw.com.xvpower.testespresso;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import tw.com.xvpower.testespresso.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       ActivityMainBinding amb =
               ActivityMainBinding.inflate(getLayoutInflater());

        amb.calcuBtn.setOnClickListener(v->{
            int n1 =  Integer.parseInt(amb.number1.getText().toString());
            int n2 =  Integer.parseInt(amb.number2.getText().toString());
            int ans = n1 + n2;
            amb.ansText.setText(String.valueOf(ans));
        });
        setContentView(amb.getRoot());


    }
}
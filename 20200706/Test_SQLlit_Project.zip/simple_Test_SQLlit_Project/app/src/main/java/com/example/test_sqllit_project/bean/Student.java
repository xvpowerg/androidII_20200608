package com.example.test_sqllit_project.bean;

import android.content.Intent;

import java.util.Objects;

public class Student {
    private long id;
    private String name;
    private int score;
    public static final String DB_NAME_KEY = "name";
    public static final String DB_SCORE_KEY = "score";

    public Student( String name, String score) {

        this(-1,name, Integer.parseInt(score));
    }

    public Student(long id, String name, int score) {
        this.id = id;
        this.name = name;
        this.score = score;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return id == student.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public Student clone(){
        Student newSt = new Student(id,name,score);
        return newSt;
    }
}

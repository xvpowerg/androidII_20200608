package com.example.test_sqllit_project.adapter;

import android.content.Context;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.test_sqllit_project.MainActivity;
import com.example.test_sqllit_project.R;
import com.example.test_sqllit_project.bean.Student;

import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.MyViewHolder> {
    private Context context;
    private List<Student> list;
    private int position;
    public StudentAdapter(Context context, List<Student> list){
                this.context = context;
                this.list = list;
    }

    public int getPosition(){
        return this.position;
    }
    private void setPosition(int position){
            this.position = position;
    }
    public void add(Student st){
        list.add(st);
        notifyItemInserted(list.size() - 1);
        //notifyDataSetChanged();
    }

    public Student get(){
        return get(getPosition());
    }
    public Student get(int postion){
        Student st = list.get(postion);
        //Student newSt = new Student(st.getId(),st.getName(),st.getScore());
        //clone 確保Student不會被修改
        //只能透過 Adpater的方式修改
        return st.clone();
    }

    public void update(Student st){
        update(st,getPosition());
    }
    public void update(Student st,int index){
        list.set(index,st);
        notifyItemChanged(index);//通知RecyclerView 變動畫面
    }
    public void delete(){
        delete(getPosition());
    }
    public void delete(int index){
        list.remove(index);
        notifyItemRemoved(index);
    }

    class MyViewHolder extends RecyclerView.ViewHolder
            implements View.OnCreateContextMenuListener{
        TextView nameText;
        TextView scoreText;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            itemView.setOnCreateContextMenuListener(this);
        }

        @Override
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
            MainActivity ma = (MainActivity) context;
            ma.getMenuInflater().inflate(R.menu.context_menu,menu);
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view =  LayoutInflater.from(context).inflate(R.layout.list_view_layout,parent,
                false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        myViewHolder.nameText = view.findViewById(R.id.nameText);
        myViewHolder.scoreText = view.findViewById(R.id.scoreText);

        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Student tmpSt =  list.get(position);
        holder.nameText.setText(tmpSt.getName());
        holder.scoreText.setText(String.valueOf(tmpSt.getScore()));
        holder.itemView.setOnLongClickListener((v)->{
            this.setPosition(holder.getAdapterPosition());
            //假設我的某個view有兩組 Listener
            // 如果回傳false表示 兩組Listener 有機會同時觸發
            //如果回傳true表示 只有OnLongClickListener 會觸發
            return false;
        });

    }
    @Override
    public int getItemCount() {
        return list.size();
    }

}

package com.example.test_sqllit_project;

import android.content.Context;
import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import com.example.test_sqllit_project.bean.Student;
import com.example.test_sqllit_project.sqlite.DBHelper;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class TestSQLiteTest {
        static Student tmpSt = null;
        static Context context ;
    @BeforeClass
    public static void init(){
         context = InstrumentationRegistry.
                 getInstrumentation().getTargetContext();
    }
    @Test
        public void aInsert(){
            DBHelper db = new DBHelper(context);
            Student st = new Student("Ken","78");
            DBHelper.InsertInfo  insertInfo = db.insert(st);
            st.setId(insertInfo.getId());
            tmpSt =st;
            assertTrue("Insert Error",insertInfo.isPass());
        }
    @Test
    public void bUpdate(){
        DBHelper db = new DBHelper(context);
        tmpSt.setName("Vivin");
       assertTrue(db.updateById(tmpSt));
    }

    @Test
    public void cDelete(){
        DBHelper db = new DBHelper(context);
        assertTrue(db.deleteByID(tmpSt));
    }

    @Test
    public void queryAll(){
        DBHelper db = new DBHelper(context);
        List<Student> list =   db.queryAll();
        assertNotEquals(0,list.size());
    }

}

package com.example.test_sqllit_project;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;


@RunWith(AndroidJUnit4.class)
public class TestUI {
    @Rule
    public ActivityTestRule<MainActivity> activityTestRule =
            new ActivityTestRule<>(MainActivity.class);
    @Test
    public void aTestInsert(){
          onView(withId(R.id.fab)).perform(click());
          onView(withId(R.id.nameET)).perform(typeText("Vivin"));
          onView(withId(R.id.scoreET)).perform(typeText("83"));
          onView(withId(android.R.id.button1)).perform(click());
      }
}

package tw.com.xvpower.ch3_2_testgson;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import tw.com.xvpower.ch3_2_testgson.bean.Person;
import tw.com.xvpower.ch3_2_testgson.bean.Skill;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Person p1 = new Person("Ken",25);
        Skill sk1 = new Skill();
        Skill sk2 = new Skill();
        p1.appenSkilles(sk1);
        sk1.setLevel(5);
        sk1.setType("跑步");
        p1.appenSkilles(sk2);
        sk2.setLevel(10);
        sk2.setType("設計");
        Gson gson = new GsonBuilder().create();
        String json = gson.toJson(p1);
        Log.d("Howard","json:"+json);

    }
}
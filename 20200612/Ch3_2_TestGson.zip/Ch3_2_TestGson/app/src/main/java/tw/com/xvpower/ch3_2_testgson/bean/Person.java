package tw.com.xvpower.ch3_2_testgson.bean;

import java.util.ArrayList;
import java.util.List;

public class Person {
    private String name;
    private int age;
    private List<Skill> skilles = new ArrayList<>();
    public Person(){ }
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
    public void appenSkilles(Skill skille) {
        skilles.add(skille);
    }
}

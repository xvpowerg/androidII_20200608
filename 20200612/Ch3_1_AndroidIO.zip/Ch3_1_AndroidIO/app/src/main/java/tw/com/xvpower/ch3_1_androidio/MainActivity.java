package tw.com.xvpower.ch3_1_androidio;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

import tw.com.xvpower.ch3_1_androidio.bean.CacheFileData;

public class MainActivity extends AppCompatActivity {
        private TextView msgTxt;
        private CacheFileData cfd = new CacheFileData();
        private void saveFile(String fileName,String data){
              try(FileOutputStream fout= openFileOutput(fileName,MODE_PRIVATE);
                  OutputStreamWriter osw = new OutputStreamWriter(fout);
              ){
                  osw.write(data);
                  Toast.makeText(this,"File save",Toast.LENGTH_SHORT).show();
              }catch (FileNotFoundException ex){
                  Log.e("Howard","FileNotFoundException:"+ex);
              }catch(IOException ex){
                  Log.e("Howard","IOException:"+ex);
              }
        }

        private String onReadFileToString( String fileName){
//            Log.d("Howard","getFilesDir():"+getFilesDir());
            StringBuilder sb = new StringBuilder();
           try(FileInputStream fin =  openFileInput(fileName);
             BufferedReader br = new  BufferedReader(  new InputStreamReader(fin));
           ){
                    String data = null;
                    while( (data = br.readLine())!= null ){
                        sb.append(data);
                    }

           }catch(FileNotFoundException ex){
                Log.e("Howard","ReadFile FileNotFoundException:"+ex);
           }catch(IOException ex){
               Log.e("Howard","ReadFile IOException:"+ex);
           }
            String result = sb.toString();

            return result;
        }
        private void onClickSaveFile(View view){
            String fileName = "myFile.txt";
            String data = "PS5 的主機外觀如同先前所發表的新版無線控制器 DualSense，" +
                    "同樣採用黑白相間的雙色設計，流線造型更添科技感。" +
                    "新主機除了配備 UHD 超高畫質藍光光碟機的標準型號外，" +
                    "也同時推出另一款沒有光碟機的數位版（Digital Edition），" +
                    "在發售時為玩家提供不同於過往的選擇。";
            saveFile(fileName,data);
        }

    private void onClickReadFile(View view){
        String fileName = "myFile.txt";
        String result = onReadFileToString(fileName);
        msgTxt.setText(result);
    }


    private void saveCache(String name, String data){
           File cacheDir =  getCacheDir();
            File file = new File(cacheDir.getAbsolutePath(),name);
            try(FileOutputStream fout = new FileOutputStream(file);
               OutputStreamWriter write = new OutputStreamWriter(fout)){
                write.write(data);
            }catch(FileNotFoundException ex){
                Log.d("Howard","ex:"+ex);
            }catch (IOException ex){
                Log.d("Howard","ex:"+ex);
            }
           //NIO2
//          Path path =  cacheDir.toPath();
//          Path filePath = path.resolve(name);
//          Files.write(filePath,data.getBytes());
           //Log.d("Howard","cacheDir:"+cacheDir);
    }

    private void onClickSaveCache(View view){
            String name = "cache.txt";
//        Log.d("Howard","data:"+cfd.getSaveFormatString());
        saveCache(name,cfd.getSaveFormatString());
    }

    private String readCacheToString(String name){
        String result = "";

        File cacheDir =  getCacheDir();
        File file = new File(cacheDir.getAbsolutePath(),name);
       try(FileInputStream fin = new FileInputStream(file);
          InputStreamReader inR = new InputStreamReader(fin);){

           StringBuilder sb = new StringBuilder();
            char[] buffer = new char[128];
            int index = -1;
          while( (index = inR.read(buffer)) != -1){
              sb.append(buffer,0,index);
          }
        result = sb.toString();
       }catch(FileNotFoundException ex){
            Log.e("Howard"," readCache:"+ex);
       }catch(IOException ex){
           Log.e("Howard"," readCache:"+ex);
       }
        cfd.parseString(result);

        return cfd.toString();
    }
    private void onClickReadCache(View view){
        String name = "cache.txt";
       String result =  readCacheToString(name);
        msgTxt.setText(result);

        Log.d("Howard","CacheFileData:"+cfd);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        msgTxt = findViewById(R.id.msgTextView);
        Button saveFileBtn = findViewById(R.id.saveFileBtn);
        saveFileBtn.setOnClickListener(this::onClickSaveFile);
        Button saveCacheBtn = findViewById(R.id.saveCache);
        saveCacheBtn.setOnClickListener(this::onClickSaveCache);

       Button readFileBtn =  findViewById(R.id.readFileBtn);
       readFileBtn.setOnClickListener(this::onClickReadFile);
       Button readCacheBtn =  findViewById(R.id.readCacheBtn);
        readCacheBtn.setOnClickListener(this::onClickReadCache);
    }



}
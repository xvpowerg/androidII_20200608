package tw.com.xvpower.ch3_1_androidio.bean;

import java.util.Calendar;

public class CacheFileData {
     Calendar calendar = Calendar.getInstance();
    private  int count = 0;
    private int h = calendar.get(Calendar.HOUR_OF_DAY);
    private int m = calendar.get(Calendar.MINUTE);
    private int s = calendar.get(Calendar.SECOND);

    public void parseString(String data){
        String[] tmp1 = data.split(",");
        count = Integer.parseInt(tmp1[0].split(":")[1]);
        String[] timeArray =
                tmp1[1].split(":")[1].split("_");
        h =  Integer.parseInt(timeArray[0]);
        m = Integer.parseInt(timeArray[1]);
        s = Integer.parseInt(timeArray[2]);
    }
    public String getSaveFormatString(){
        Calendar calendar = Calendar.
                getInstance();
         h = calendar.get(Calendar.HOUR_OF_DAY);
         m = calendar.get(Calendar.MINUTE);
         s = calendar.get(Calendar.SECOND);
         count++;
         String data = String.
                 format("count:%d,time:%d_%d_%d",count,h,m,s);
        return  data;
    }
    public String toString(){
        return String.format("數量:%d 時間:%d:%d:%d",
                                count,h,m,s);
    }


}

package tw.com.xvpower.ch16_2_otherprojectsendmsg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
      Button sendBtn =   findViewById(R.id.sendMsgBtn);
        sendBtn.setOnClickListener(v->{
            Intent action = new Intent("test.br.MyReceiver3");
            action.putExtra("msg","vivin");
            sendBroadcast(action);
        });
    }
}
package tw.com.xvpower.ch16_4_widget_1;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class TestAppWidget extends AppWidgetProvider {
    //Widget 有限定可用Layout
    //FrameLayout
    //LinearLayout
    //RelativeLayout
    //GridLayout
//https://developer.android.com/guide/topics/appwidgets/index.html#CreatingLayout


    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        Log.d("Howard","onReceive");
    }
    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        super.onUpdate(context, appWidgetManager, appWidgetIds);
        Log.d("Howard","onUpdate");
    }
    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        super.onDeleted(context, appWidgetIds);
        Log.d("Howard","onDeleted");
    }
    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        //第一個widget會呼叫 onEnabled
        Log.d("Howard","onEnabled");
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
        //沒有 widget時呼叫 onDisabled
        Log.d("Howard","onDisabled");
    }
}

package tw.com.xvpower.ch16_1_brodcatreceiver2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class ScreenReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
            switch (intent.getAction()){
                case Intent.ACTION_SCREEN_ON:
                    Log.d("Howard","SCREEN ON....");
                    break;
                case Intent.ACTION_SCREEN_OFF:
                    Log.d("Howard","SCREEN OFF....");
                    break;
            }
    }
}

package tw.com.xvpower.ch16_1_brodcatreceiver2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    private TextView msgInfoText;
    private ScreenReceiver screenReceiver = new ScreenReceiver();
    private BroadcastReceiver myReceiver= new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
              String msg =  intent.getStringExtra("msg");
            msgInfoText.setText("收到訊息了!!:"+msg);
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       Button sendMSgBtn =  findViewById(R.id.sendMsg);
        msgInfoText = findViewById(R.id.showMsgTxt);
        sendMSgBtn.setOnClickListener(v->{
            Intent actionIntent = new Intent("test.br.MyReceiver3");
            actionIntent.putExtra("msg","Howard");
            sendBroadcast(actionIntent);
        });

        Button unregistBtn = findViewById(R.id.unregistBtn);
        unregistBtn.setOnClickListener(v->{
            // 取消接收器註冊
                unregisterReceiver(myReceiver);
            Toast.makeText(this,"取消接收",Toast.LENGTH_SHORT).show();
        });

         CheckBox checkBox =  findViewById(R.id.checkBox1);
        checkBox.setOnCheckedChangeListener((c,isChecked)->{
                    if (isChecked){
                            IntentFilter filter = new IntentFilter();
                        filter.addAction(Intent.ACTION_SCREEN_ON);
                        filter.addAction(Intent.ACTION_SCREEN_OFF);
                        registerReceiver(screenReceiver,filter);
                    }else{
                        unregisterReceiver(screenReceiver);
                    }

        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter filter2 = new IntentFilter();
        filter2.addAction("test.br.MyReceiver3");
        registerReceiver(myReceiver,filter2);
    }


}
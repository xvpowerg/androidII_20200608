package tw.com.xvpower.ch16_3_test_boot_completed;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class MyBootCompletedReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("tw.com.toMainActivity2")){
            Intent newIntent = new Intent(context,MainActivity2.class);
            context.startActivity(newIntent);
        }else{
            Log.d("Howard","My Boot Completed....");
        }

    }
}

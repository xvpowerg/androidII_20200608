package tw.com.xvpower.ch16_3_test_boot_completed;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private MyBootCompletedReceiver receiver = new MyBootCompletedReceiver();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn =   findViewById(R.id.startActivityBtn);
        IntentFilter ifilter = new  IntentFilter();
        ifilter.addAction("tw.com.toMainActivity2");
        registerReceiver(receiver,ifilter);
        btn.setOnClickListener(v ->{
            Intent actionInt = new Intent("tw.com.toMainActivity2");
            sendBroadcast(actionInt);
        });

    }
}
package tw.com.xvpower.sqliteproject.view;

public class MyLiveData<T> {
    private T value;
    private MyObserver<T> myObserver;

    public void setMyObserver(MyObserver<T> myObserver){
        this.myObserver = myObserver;
    }
    public void setValue(T value){
        this.value = value;
        if (myObserver != null)
        myObserver.observer(value);
    }
    public T getValue(){
        return value;
    }

}

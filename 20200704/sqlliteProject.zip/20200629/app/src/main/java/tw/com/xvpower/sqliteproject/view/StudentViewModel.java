package tw.com.xvpower.sqliteproject.view;

import android.content.Context;

import java.util.List;

import tw.com.xvpower.sqliteproject.model.StudentDao;
import tw.com.xvpower.sqliteproject.model.data.Student;
import tw.com.xvpower.sqliteproject.sqlite.DBHelper;

//ViewModel 內做作一些修改
//目的 資料庫 跟 Activity完全脫離
public class StudentViewModel {
        private  MyLiveData<List<Student>> studentsLiveData;
        private Context context;
        private StudentDao sdao;
        private List<Student> stList;
        public  StudentViewModel(Context context)
        {
            studentsLiveData = new MyLiveData();
            this.context = context;
            sdao =  DBHelper.getStudentDao(context);

        }
      public  StudentViewModel(MyObserver<List<Student>> myObs,Context context){
                studentsLiveData = new MyLiveData();
                studentsLiveData.setMyObserver(myObs);
                this.context = context;
                sdao =  DBHelper.getStudentDao(context);
        }

        public MyLiveData  getStudentsLiveData(){
            return studentsLiveData;
        }

        public void queryAll(){
             stList =  sdao.queryAll();
            refresh();
        }

        public void insertStudent(Student st){
            sdao.insert(st);
            stList.add(st);
            refresh();
        }

        public void deleteStudent(Student st){
            sdao.deleteById(st.getId());
            stList.remove(st);
            refresh();
        }
        public void updateStudent(Student st){
            sdao.updateById(st);
//            int index = stList.indexOf(st);
//            stList.set(index,st);
            refresh();
        }

        public  void refresh(){
            studentsLiveData.setValue(stList);
        }
}

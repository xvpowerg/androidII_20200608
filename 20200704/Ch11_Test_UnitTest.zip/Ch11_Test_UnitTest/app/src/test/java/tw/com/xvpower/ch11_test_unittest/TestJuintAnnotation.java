package tw.com.xvpower.ch11_test_unittest;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestJuintAnnotation {

    @BeforeClass
    public static void init(){
        //物件被創造時呼叫
        //只會呼叫一次
        System.out.println("----BeforeClass----");
    }
    @Before
    public void setUp(){
        //呼叫方法前被呼叫
        //呼叫多次
        System.out.println("----Before----");
    }
    @After
    public  void testAfter(){
        //呼叫方法後被呼叫
        //呼叫多次
        System.out.println("----After----");
    }

    @AfterClass
    public static void testAfterClass(){
        //物件結束時呼叫
        //只會呼叫一次
        System.out.println("----AfterClass----");
    }
    @Test
    public void atest1(){
        System.out.println("test1!!");
    }

    @Test
    public void btest2(){
        System.out.println("test2!!");
    }

    @Test
    public void cabc(){
        System.out.println("abc!!");
    }
}

package tw.com.xvpower.ch11_test_unittest;

import org.junit.Test;

import tw.com.xvpower.ch11_test_unittest.calculate.MyMath;

import static org.junit.Assert.*;
public class MyObjecTest1 {
    @Test
    public void myMathTest(){
        int a = 3;
        int b = 5;
        assertEquals(8,MyMath.addition(a,b));
    }
}

package tw.com.xvpower.ch11_test_unittest.calculate;

public class MyMath {
        public static int addition(int a,int b){
            return a + b;
        }

}

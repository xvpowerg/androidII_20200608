package tw.com.xvpower.ch11_test_unittest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import tw.com.xvpower.ch11_test_unittest.calculate.MyMath;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        int ans =   MyMath.addition(3,5);
        Log.d("Howard","ans:"+ans);
    }
}
package tw.com.xvpower.firebase_photoproject_20200724;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {
        private EditText emailText;
        private EditText pass1Text;
        private EditText pass2Text;
        private FirebaseAuth mAuth;
    private void init(){
        emailText = findViewById(R.id.accountTxt);
        pass1Text = findViewById(R.id.passText1);
        pass2Text = findViewById(R.id.passText2);
    }
    private void onRegisterCompleteListener(Task<AuthResult> task){
        if (task.isSuccessful()){
            Intent mainIntent = new Intent(this,MainActivity.class);
            startActivity(mainIntent);
            Toast.makeText(this,
                    R.string.app_register_successful,Toast.LENGTH_SHORT).show();
            finish();
        }else{
            String msg =   getString(R.string.app_register_failure)+
                            ":"+task.getException().toString();
            Toast.makeText(this,msg,
                    Toast.LENGTH_SHORT).show();

        }

    }

    private void register(View v){
        String email = emailText.getText().toString();
        String pass1 = pass1Text.getText().toString();
        String pass2 = pass2Text.getText().toString();

        if (TextUtils.isEmpty(email) ||
                TextUtils.isEmpty(pass1) || TextUtils.isEmpty(pass2)){
            Toast.makeText(this,"帳號密碼不可空白",
                            Toast.LENGTH_SHORT).show();
        }else if(pass1.compareTo(pass2) != 0){
            Toast.makeText(this,R.string.app_confirm_pass_fail,
                    Toast.LENGTH_SHORT).show();
        }else{
            mAuth.createUserWithEmailAndPassword(email,pass1).
                    addOnCompleteListener(this::onRegisterCompleteListener);
        }

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        init();
        mAuth = FirebaseAuth.getInstance();
        Button regBtn =    findViewById(R.id.reg_btn);
        regBtn.setOnClickListener(this::register);
    }
}
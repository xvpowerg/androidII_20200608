package tw.com.xvpower.testfirebaselogin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    private EditText accountETxt;
    private EditText passEText;
    private FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        firebaseAuth = FirebaseAuth.getInstance();
        accountETxt = findViewById(R.id.account_txt);
        passEText = findViewById(R.id.pass_txt);
     Button regBtn =  findViewById(R.id.register_btn);
     Button loginBtn = findViewById(R.id.login_btn);
        regBtn.setOnClickListener(v->{
            String account = accountETxt.getText().toString();
            String pass = passEText.getText().toString();
            firebaseAuth.createUserWithEmailAndPassword(account,pass).
                    addOnCompleteListener(task->{
                    if (task.isSuccessful()){
                        Log.d("Howard","Success");
                    }else{
                        Log.w("Howard","Faill!"+task.getException());
                    }
            });

        });
        loginBtn.setOnClickListener(v->{
                String email = accountETxt.getText().toString();
                String pass = passEText.getText().toString();
            firebaseAuth.signInWithEmailAndPassword(email,pass).
                    addOnCompleteListener(task->{
                                if (task.isSuccessful()){
                                    Log.d("Howard","Login Successful");
                                }else{
                                    Log.w("Howard","Login Fail");
                                }
                    });

        });
    }
}

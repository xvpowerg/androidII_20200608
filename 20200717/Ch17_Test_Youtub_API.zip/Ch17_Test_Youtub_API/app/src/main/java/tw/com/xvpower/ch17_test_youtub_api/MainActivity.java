package tw.com.xvpower.ch17_test_youtub_api;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

public class MainActivity extends YouTubeBaseActivity {

    private String vid = "TWgkb2QUcu4";

    private class YouTubeInitListener implements YouTubePlayer.OnInitializedListener {

        @Override
        public void onInitializationSuccess(YouTubePlayer.Provider provider,
                                            YouTubePlayer youTubePlayer, boolean b) {
            youTubePlayer.cueVideo(vid);
            Log.d("Howard","onInitializationSuccess!!");
        }

        @Override
        public void onInitializationFailure(YouTubePlayer.Provider provider,
                                            YouTubeInitializationResult youTubeInitializationResult) {
            Log.d("Howard","onInitializationFailure!!");
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String  apiKey =  getString(R.string.API_KEY);
        YouTubePlayerView pv = findViewById(R.id.youtube_view);
        YouTubeInitListener yin = new YouTubeInitListener();
        pv.initialize(apiKey,yin);
    }
}
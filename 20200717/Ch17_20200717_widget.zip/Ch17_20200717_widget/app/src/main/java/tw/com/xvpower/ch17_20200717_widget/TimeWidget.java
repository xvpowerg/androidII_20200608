package tw.com.xvpower.ch17_20200717_widget;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.util.Log;
import android.widget.RemoteViews;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

/**
 * Implementation of App Widget functionality.
 */
public class TimeWidget extends AppWidgetProvider {
    private AppWidgetManager manager;
    private RemoteViews remoteViews;
    private ComponentName thisWidget;


    private void restTime(){
        while (true) {
            updateTime();
            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void updateTime(){
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR);
        int minute = calendar.get(Calendar.MINUTE);
        int second =   calendar.get(Calendar.SECOND);
        String time = String.format("%02d:%02d:%02d",
                        hour,minute,second);
        remoteViews.setTextViewText(R.id.time_text,time);
        manager.updateAppWidget(thisWidget,remoteViews);

    }
    @Override
    public void onUpdate(Context context,
                         AppWidgetManager appWidgetManager,
                         int[] appWidgetIds) {
        Log.d("Howard","onUpdate");
        thisWidget = new ComponentName(context,TimeWidget.class);
        manager = AppWidgetManager.getInstance(context);
        remoteViews = new RemoteViews(context.getPackageName(),
                R.layout.time_widget);

        Thread th = new Thread(this::restTime);
        th.start();

    }


}


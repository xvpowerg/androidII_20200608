package tw.com.xvpower.ch17_20200717_widget2;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.widget.RemoteViews;

import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Implementation of App Widget functionality.
 */
public class GitataWidget extends AppWidgetProvider {
     private Bitmap[] bitmaps = new Bitmap[24];
      private RemoteViews remoteViews;
      private AppWidgetManager manager;
      private ComponentName thisWidget;
      private ScheduledExecutorService executorService;
      private int index = 0;
      private static boolean runAnimation = true;
      public static final String TOUCH_GITATA = "touch_gitata";
     private  void initImages(Context context){
         String imageFileName = "gitgit%d.png";
         for (int i = 0; i < bitmaps.length;i++){
             String fileName = String.format(imageFileName,i+1);
              try(InputStream is =
                          context.getAssets().
                                  open(String.format(fileName))){
            Bitmap bitmap = BitmapFactory.decodeStream(is);
                  bitmaps[i] = bitmap;
              }catch (IOException ex){
                  Log.e("Howard","IOException:"+ex);
              }
         }
     }

     private void updateImages(){
               if (runAnimation){
                   remoteViews.setImageViewBitmap(R.id.gitgitImageView,bitmaps[index]);
                   index = ++index % bitmaps.length;
                   manager.updateAppWidget(thisWidget,remoteViews);
               }

     }

     private void initClickImageView(Context context){
         Intent intentBtn = new Intent(context,GitataWidget.class);
         intentBtn.setAction(TOUCH_GITATA);
         PendingIntent pendingIntent = PendingIntent.getBroadcast(context,
                 0,
                 intentBtn,PendingIntent.FLAG_UPDATE_CURRENT);
         remoteViews.setOnClickPendingIntent(R.id.gitgitImageView,pendingIntent);
     }
    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
         thisWidget = new ComponentName(context,GitataWidget.class);
         manager = AppWidgetManager.getInstance(context);
         remoteViews = new RemoteViews(context.getPackageName(),R.layout.gitata_widget);
         executorService = Executors.newSingleThreadScheduledExecutor();
         initImages(context);
        initClickImageView(context);
        executorService.scheduleAtFixedRate(this::updateImages,0,100,
                                             TimeUnit.MILLISECONDS);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (intent.getAction().equals(TOUCH_GITATA)){
            runAnimation = !runAnimation;
        }
    }
}


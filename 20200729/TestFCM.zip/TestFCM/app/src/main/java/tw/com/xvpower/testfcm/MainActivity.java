package tw.com.xvpower.testfcm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FirebaseInstanceId.getInstance().getInstanceId().
                addOnCompleteListener ((Task<InstanceIdResult> task)->{
                               if (!task.isSuccessful()){
                                  return;
                               }
                    String token =
                            task.getResult().getToken();
                    Log.d("Howard",token);

                });

    }
}
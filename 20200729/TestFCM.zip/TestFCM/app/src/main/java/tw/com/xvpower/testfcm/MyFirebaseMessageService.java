package tw.com.xvpower.testfcm;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFirebaseMessageService  extends FirebaseMessagingService {
    private String CHANNEL_ID = "FcmMsg";

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void createChannel(){
          NotificationManager notificationManager =
                  (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

          if (notificationManager.getNotificationChannel(CHANNEL_ID) != null){
                return;
          }
          final  String name = "ForFCM";
          final String decName = "FCM MSG";
          final int importance = NotificationManager.IMPORTANCE_DEFAULT;
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID,name,importance);
        channel.setDescription(decName);
        notificationManager.createNotificationChannel(channel);
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);

        RemoteMessage.Notification  rn = remoteMessage.getNotification();
        if (rn != null){
            createChannel();
            String body =   rn.getBody();
            String title = rn.getTitle();

            NotificationCompat.Builder builder =
                    new NotificationCompat.Builder(this,CHANNEL_ID);
            builder.setSmallIcon(R.drawable.fcm_file_24);
            builder.setContentTitle(title);
            builder.setContentText(body);
            NotificationManagerCompat.from(this).notify(1,builder.build());
            Log.d("Howard","Body:"+body+" Title:"+title);
        }


    }
}

package tw.com.xvpower.firebase_photoproject_20200724;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import tw.com.xvpower.firebase_photoproject_20200724.adapter.ImageAdapter;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private Toolbar toolbar;
    private ImageAdapter imageAdapter;
    private void lgoin(){
        Intent intent = new Intent(this,LoginActivity.class);
        startActivity(intent);
        finish();
    }
    private void logout(){
        mAuth.signOut();
        lgoin();
    }
    private void upload(){
        Intent toUpload = new Intent(this,UploadActivity.class);
        startActivity(toUpload);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();
        toolbar =  findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(R.string.app_title);

    }


    private void loadImage(String userId){
             RecyclerView rcView =  findViewById(R.id.rcView);
          if (imageAdapter == null){
              imageAdapter = new ImageAdapter(userId);
              LinearLayoutManager linearLayoutManager =
                      new LinearLayoutManager(this);
              rcView.setLayoutManager(linearLayoutManager);
              rcView.setAdapter(imageAdapter);
          }

    }
    @Override
    protected void onStart() {
        super.onStart();
       FirebaseUser currentUser =  mAuth.getCurrentUser();
       if (currentUser == null){
           //未登入
           lgoin();
       }else{
           //以登入
           loadImage(currentUser.getUid());

       }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.menu_logout:
                logout();
                break;
            case R.id.menu_upload:
                upload();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
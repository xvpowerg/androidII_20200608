package tw.com.xvpower.firebase_photoproject_20200724.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;

import java.util.ArrayList;
import java.util.List;

import tw.com.xvpower.firebase_photoproject_20200724.R;
import tw.com.xvpower.firebase_photoproject_20200724.beans.MyImageInfo;

public class ImageAdapter  extends  RecyclerView.Adapter<ImageAdapter.MyViewHolder>  {
    private FirebaseFirestore firebaseFirestore;
    private List<MyImageInfo> dataList = new ArrayList<>();

    private void onReadFireBaseEven(QuerySnapshot snapshot,
                                    FirebaseFirestoreException ex){

        if (ex != null){
            Log.e("Howard","onReadFireBaseEven:"+ex);
            return;
        }
        List<DocumentSnapshot> list= snapshot.getDocuments();
        for (DocumentSnapshot ds : list){
               String imageUri =  ds.get("image",String.class);
               String msg =  ds.get("image_msg",String.class);
            MyImageInfo imageInfo = new MyImageInfo(imageUri,msg);
            dataList.add(imageInfo);
        }
        notifyDataSetChanged();
    }

    public ImageAdapter(String userId){
        firebaseFirestore = FirebaseFirestore.getInstance();
        firebaseFirestore.collection("Users").
                document(userId).collection("images").
                addSnapshotListener(this::onReadFireBaseEven);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view =   LayoutInflater.from(parent.getContext()).
                inflate(R.layout.rc_view_layout,parent,false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        myViewHolder.imageView = view.findViewById(R.id.blogImageVIew);
        myViewHolder.textView = view.findViewById(R.id.imageMsgTxt);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
         MyImageInfo info =  dataList.get(position);
        holder.textView.setText(info.getMessage());
        RequestOptions rq = new RequestOptions();
        rq.placeholder(R.drawable.ic_baseline_child_care_24);
        Glide.with(holder.getContext()).
                setDefaultRequestOptions(rq).
                load(info.getImageUri()).into(holder.imageView);

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

     class MyViewHolder  extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textView;
        public Context getContext(){
            return textView.getContext();
        }
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}

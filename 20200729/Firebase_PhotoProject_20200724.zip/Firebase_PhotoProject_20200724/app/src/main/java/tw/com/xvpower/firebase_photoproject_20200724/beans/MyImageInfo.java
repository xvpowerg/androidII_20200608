package tw.com.xvpower.firebase_photoproject_20200724.beans;

import android.net.Uri;

public class MyImageInfo {
    private Uri imageUri;
    private String message;

    public MyImageInfo(Uri imageUri,String message){
        this.imageUri =imageUri;
        this.message = message;
    }
    public MyImageInfo(String imageUri,String message){
        this(Uri.parse(imageUri),message);
    }

    public Uri getImageUri() {
        return imageUri;
    }

    public void setImageUri(Uri imageUri) {
        this.imageUri = imageUri;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String toString(){
        return "imageUri:"+imageUri.toString()+" Message:"+message;
    }

}

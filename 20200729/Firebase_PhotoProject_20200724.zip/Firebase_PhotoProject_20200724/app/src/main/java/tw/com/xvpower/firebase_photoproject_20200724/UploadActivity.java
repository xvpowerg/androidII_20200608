package tw.com.xvpower.firebase_photoproject_20200724;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.util.HashMap;
import java.util.Map;

public class UploadActivity  extends AppCompatActivity {
    private ImageView previewImageView = null;
    private EditText msgText = null;
    private ProgressBar progressBar;
    private StorageReference mStorageRef;
    private Uri mainImageURI;
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore  firebaseFirestore;
    private String userId ;

    private void openCropImage(){
        //setGuidelines(CropImageView.Guidelines.ON) 是否要隔線
        CropImage.activity().
                setGuidelines(CropImageView.Guidelines.ON).
                setAspectRatio(1,1).
                start(this);
    }
    private void  openPackage(View view){
           if (ContextCompat.checkSelfPermission(this,
                   Manifest.permission.READ_EXTERNAL_STORAGE) !=
                   PackageManager.PERMISSION_GRANTED){
               ActivityCompat.requestPermissions(this,
                       new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                       100);
           }else{
               openCropImage();
           }
    }
    private void upload(View view){
        if (mainImageURI != null){
            progressBar.setVisibility(View.VISIBLE);
          UploadTask uploadTask =   mStorageRef.
                    child("upload_images").child(userId).
                  child(System.currentTimeMillis()+".jpg").putFile(mainImageURI);
            uploadTask.addOnCompleteListener(task->{
                    if (task.isSuccessful()){
                        Toast.makeText(this, "上傳成功",
                                Toast.LENGTH_SHORT).show();
                        Task<Uri>  result = task.getResult().getMetadata().
                                getReference().getDownloadUrl();
                        result.addOnSuccessListener(uri->{
                            String msg = msgText.getText().toString();
                            toDatabase(msg,uri.toString());
                        });
                    }else{
                            String error = task.getException().getMessage();
                            Log.e("Howard","upload error:"+error);
                        Toast.makeText(this, "上傳失敗",
                                Toast.LENGTH_SHORT).show();
                    }

                progressBar.setVisibility(View.GONE);
            });
        }
    }

    private void toDataBaseComplete(Task<Void> task){
            if (task.isSuccessful()){
                Toast.makeText(this,"存檔完成",Toast.LENGTH_SHORT).show();
                finish();
            }else{
                Toast.makeText(this,"存檔失敗",Toast.LENGTH_SHORT).show();
                String msg = task.getException().getMessage();
                Log.e("Howard","data base 寫入失敗"+msg);
            }
    }

    private void toDatabase(String msg,String uri){
        HashMap<String,String> data = new HashMap<>();
        data.put("image_msg",msg);
        data.put("image",uri);
        firebaseFirestore.
                collection("Users").
                document(userId).
                collection("images").
                document(System.currentTimeMillis()+"").
                set(data).addOnCompleteListener(this::toDataBaseComplete);

    }

//    private void  toDatabase(){
//        //collection
//        //collection 下只能新增 document
//        //document 下能新增 collection or set
//        Map data = new HashMap();
//        data.put("name","Ken");
//        data.put("age",26);
//        firebaseFirestore.collection("Person").
//                document("123").set(data);
//    }
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);
        previewImageView = findViewById(R.id.select_image);
        msgText = findViewById(R.id.msg_txt);
        previewImageView.setOnClickListener(this::openPackage);
        mStorageRef = FirebaseStorage.getInstance().getReference();
        progressBar = findViewById(R.id.progressBar);
        firebaseAuth = FirebaseAuth.getInstance();
        userId =  firebaseAuth.getCurrentUser().getUid();
        firebaseFirestore = FirebaseFirestore.getInstance();
        Button uploadBtn = findViewById(R.id.upload_btn);
        uploadBtn.setOnClickListener(this::upload);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            openCropImage();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        CropImage.ActivityResult result =
                        CropImage.getActivityResult(data);
        if (resultCode == RESULT_OK){
            mainImageURI =  result.getUri();
            previewImageView.setImageURI(mainImageURI);
        }else if(resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE){
            Exception ex =   result.getError();
            Log.d("Howard","Error:"+ex);
        }
    }
}

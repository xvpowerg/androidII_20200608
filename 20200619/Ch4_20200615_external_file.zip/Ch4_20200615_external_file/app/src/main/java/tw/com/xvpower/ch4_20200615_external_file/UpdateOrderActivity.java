package tw.com.xvpower.ch4_20200615_external_file;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
import java.util.ArrayList;

import tw.com.xvpower.ch4_20200615_external_file.bean.Order;
import tw.com.xvpower.ch4_20200615_external_file.bean.Product;
import tw.com.xvpower.ch4_20200615_external_file.data.OrderDao;
import tw.com.xvpower.ch4_20200615_external_file.data.json.JsonTools;
import tw.com.xvpower.ch4_20200615_external_file.data.json.OrderJsonData;

public class UpdateOrderActivity extends AppCompatActivity {
    private class MyViewHold{
        EditText nameText;
        EditText priceText;
        public MyViewHold(EditText nameText, EditText priceText) {
            this.nameText = nameText;
            this.priceText = priceText;
        }
        public Product parseProduct(){
            String name = nameText.getText().toString();
            String price =  priceText.getText().toString();
            if (name.isEmpty() == false &&
                    price.isEmpty() == false){
                Product prod = new Product();
                prod.setName(name);
                prod.setPrice(Integer.parseInt(price));
                return prod;
            }
            return null;
        }
    }
   private  LinearLayout pGroup;
   private ArrayList<MyViewHold> myViewHolds = new ArrayList<>();
    private File jsonFileDir;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_order);
        FloatingActionButton fb =  findViewById(R.id.addFab);
            pGroup =  findViewById(R.id.productGroup);
         jsonFileDir = getExternalFilesDir("json");
        fb.setOnClickListener((v)->{
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setOrientation(LinearLayout.HORIZONTAL);
            EditText nameText = new EditText(this);
            nameText.setHint("請輸入品名");
            EditText priceText = new EditText(this);
            priceText.setHint("請輸入金額");
            priceText.setInputType(InputType.TYPE_CLASS_NUMBER);

            linearLayout.addView(nameText);
            linearLayout.addView(priceText);

            MyViewHold myViewHold =
                    new MyViewHold(nameText,priceText);
            myViewHolds.add(myViewHold);
            pGroup.addView(linearLayout);

        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.update_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.save_item:
                Order newOrder = new Order();
                for (MyViewHold  myViewHold :  myViewHolds){
                    Product p =  myViewHold.parseProduct();
                    newOrder.appendProduct(p);
                }
                //小作業
                //如何轉為Json存檔

                 OrderDao orderDao =  OrderJsonData.
                         createOrderJsonData(jsonFileDir);
                orderDao.createOrder(newOrder);

                Toast.makeText(this,"存檔成功",
                        Toast.LENGTH_SHORT).show();
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
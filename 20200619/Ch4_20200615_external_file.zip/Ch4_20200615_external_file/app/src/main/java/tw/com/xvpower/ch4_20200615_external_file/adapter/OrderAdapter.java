package tw.com.xvpower.ch4_20200615_external_file.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import tw.com.xvpower.ch4_20200615_external_file.R;
import tw.com.xvpower.ch4_20200615_external_file.bean.Order;

public class OrderAdapter extends BaseAdapter {
    private Context context;
    private List<Order> orderList;

    public OrderAdapter(Context context,List<Order> orderList){
        this.context = context;
        this.orderList = orderList;
    }
    @Override
    public int getCount() {
        return orderList.size();
    }
    @Override
    public Order getItem(int position) {
        return orderList.get(position);
    }
    @Override
    public long getItemId(int position) {
        return orderList.get(position).getOrderId();
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = LayoutInflater.from(this.context).
                inflate(R.layout.list_view_layout,
                        parent,
                        false);
             Order order =  getItem(position);
             TextView orderItemText=
                     view.findViewById(R.id.orderItemText);
        orderItemText.setText(order.toString());
        return view;
    }
}

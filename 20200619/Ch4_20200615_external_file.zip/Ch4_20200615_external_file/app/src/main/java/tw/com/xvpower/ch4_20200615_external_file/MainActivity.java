package tw.com.xvpower.ch4_20200615_external_file;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import tw.com.xvpower.ch4_20200615_external_file.adapter.OrderAdapter;
import tw.com.xvpower.ch4_20200615_external_file.bean.Order;
import tw.com.xvpower.ch4_20200615_external_file.bean.Product;
import tw.com.xvpower.ch4_20200615_external_file.bean.SerialNumber;
import tw.com.xvpower.ch4_20200615_external_file.data.OrderDao;
import tw.com.xvpower.ch4_20200615_external_file.data.json.JsonTools;
import tw.com.xvpower.ch4_20200615_external_file.data.json.OrderJsonData;

public class MainActivity extends AppCompatActivity {
    private ListView listView = null;
    private File  jsonFileDir;
    private OrderDao orderDao = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        jsonFileDir = getExternalFilesDir("json");
        listView =  findViewById(R.id.ordListView);
        View emptyView =  findViewById(R.id.my_empty_view);
        listView.setEmptyView(emptyView);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.d("Howard","id:"+id);
            }
        });
        orderDao =   OrderJsonData.createOrderJsonData(jsonFileDir);
    }

    @Override
    protected void onStart() {
        super.onStart();
       List<Order> list = orderDao.queryOrders();
        OrderAdapter oadpater =
                new OrderAdapter(this,list);
        listView.setAdapter(oadpater);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
            switch(item.getItemId()){
                case R.id.insert_order:
                    Intent toActivity = new Intent(this,
                            UpdateOrderActivity.class);
                    startActivity(toActivity);
                    break;
            }

        return super.onOptionsItemSelected(item);
    }
}
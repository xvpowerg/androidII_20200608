package tw.com.xvpower.ch4_20200615_external_file.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Order {
    private int orderId;
    private List<Product> products = new ArrayList<>();

    public int getOrderId() {
        return orderId;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    public void appendProduct(Product p){
        this.products.add(p);
    }

    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("訂單編號:"+this.getOrderId()+"\n");
         int count = 1;
        for(Product p : products){
            if (count > 3){
                sb.append("......");
                break;
            }
            sb.append("產品:"+p.getName()+","+p.getPrice()+"\n");
            count++;
        }
        return sb.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Order order = (Order) o;
        return orderId == order.orderId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(orderId);
    }
}

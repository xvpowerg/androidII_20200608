package tw.com.xvpower.ch6_1_sqlite.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    public static  final int VERSION = 2;
    public static  final String DB_NAME = "myApp.db";
    public static final String TABLE_NAME= "student";
    public static  final String CREATE_TABLE_SQL="CREATE TABLE " +
            TABLE_NAME+"(_id INTEGER PRIMARY KEY," +
            "name TEXT)";
    public DBHelper(@Nullable Context context) {
        super(context, DB_NAME,  null, VERSION);
    }
    //第一次建立資料庫時
    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("Howard","create sql:"+CREATE_TABLE_SQL);
        db.execSQL(CREATE_TABLE_SQL);
    }
    public void insertData(String name){
         SQLiteDatabase db =  getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name",name);
         db.insert(TABLE_NAME,null,cv);
    }
    public void queryData(){
        SQLiteDatabase db = this.getReadableDatabase();
         Cursor cursor =  db.rawQuery("SELECT * FROM "+TABLE_NAME,
                null);
            while (cursor.moveToNext()){
                Log.d("Howard",
                        " id:"+cursor.getInt(0)+
                                " name:"+cursor.getString(1));
            }
    }
    public void update(){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name","Lucy");
        db.update(TABLE_NAME,cv,"_id=?",new String[]{"4"});
    }
    //version 變換時
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.d("Howard","onUpgrade:"+oldVersion+":"+newVersion);
    }
}

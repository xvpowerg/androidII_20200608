package tw.com.xvpower.ch6_1_sqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import tw.com.xvpower.ch6_1_sqlite.db.DBHelper;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DBHelper  db = new DBHelper(this);
        //db.insertData("Ben");
        db.queryData();
        Log.d("Howard","======================");
        db.update();
        Log.d("Howard","======================");
        db.queryData();

    }

}
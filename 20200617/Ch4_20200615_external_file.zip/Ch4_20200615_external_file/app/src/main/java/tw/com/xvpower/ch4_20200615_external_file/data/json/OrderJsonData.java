package tw.com.xvpower.ch4_20200615_external_file.data.json;

import android.util.Log;

import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import tw.com.xvpower.ch4_20200615_external_file.bean.Order;
import tw.com.xvpower.ch4_20200615_external_file.bean.SerialNumber;
import tw.com.xvpower.ch4_20200615_external_file.data.OrderDao;

public class OrderJsonData implements OrderDao {
    private String jsonName = "order.json";
    private File jsonDirFile = null;
    private File jsonFile;
    public static OrderJsonData createOrderJsonData(
            File jsonDirFile){
          return new OrderJsonData(jsonDirFile);
    }
     OrderJsonData( File jsonDirFile){
        this.jsonDirFile = jsonDirFile;
        this.jsonFile = new File(jsonDirFile,jsonName);
    }

    public int createOrder(Order order) {

        //要先查出Json 轉換為List
        String json= JsonTools.readJson(jsonFile);
        int id =  SerialNumber.getSerial(jsonDirFile);
        order.setOrderId(id);
        ArrayList<Order> orderList = new ArrayList<>();
        TypeToken<ArrayList<Order>> typeToken =
                new TypeToken<ArrayList<Order>>(){};
        if (json != null && json.length() >1){
            orderList = JsonTools.jsonToObj(json,typeToken);
        }
        orderList.add(order);
        //將order 寫入 List
        //再將List轉為Json 之前的Json覆蓋檔案
        json = JsonTools.objToJson(orderList);
        Log.d("Howard","Create json:"+json);
        //String json = "";
        JsonTools.createJson(jsonFile,json);
        return id;
    }

    @Override
    public List<Order> queryOrders() {
        TypeToken<ArrayList<Order>> typeToken =
                new TypeToken<ArrayList<Order>>(){};
          String json = JsonTools.readJson(jsonFile);
          ArrayList<Order> orderList =  JsonTools.jsonToObj(json,typeToken);
        return orderList;
    }

    @Override
    public int updateOrder(Order order) {
             List<Order> orderList =   queryOrders();
             int index = orderList.indexOf(order);
             Log.d("Howard","updateOrder index:"+index);
             if (index < 0){ return 0;}
             orderList.set(index,order);
           String json =   JsonTools.objToJson(orderList);
        Log.d("Howard","updateOrder Json:"+json);
           JsonTools.createJson(jsonFile,json);
           return 1;
    }

    @Override
    public void deleteAll() {
        ArrayList<Order> orderList = new ArrayList<>();
        String json = JsonTools.objToJson(orderList);
        JsonTools.createJson(jsonFile,json);
    }


}

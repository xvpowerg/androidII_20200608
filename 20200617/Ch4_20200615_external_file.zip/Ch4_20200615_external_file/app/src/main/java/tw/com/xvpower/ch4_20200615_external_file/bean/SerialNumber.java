package tw.com.xvpower.ch4_20200615_external_file.bean;

import com.google.gson.reflect.TypeToken;

import java.io.File;

import tw.com.xvpower.ch4_20200615_external_file.data.json.JsonTools;

public class SerialNumber {
    private int id;
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    private void accumulate(){
        id++;
    }

    public synchronized static int getSerial(File serialDir){
        File serialFile = new File(serialDir,"SerialNumber.json");
        String json =  JsonTools.readJson(serialFile);
        SerialNumber serialNumber = null;
        if (json == null || json.length() < 1){
             serialNumber = new SerialNumber();
        }else{
            TypeToken<SerialNumber> typeToken =
                    new TypeToken<SerialNumber>(){};
            serialNumber =JsonTools.jsonToObj(json,typeToken);
        }
        serialNumber.accumulate();
        json = JsonTools.objToJson(serialNumber);
        JsonTools.createJson(serialFile,json);
            //讀取Serial的Json檔
            //把Serial內的id 加1
            //寫回Serial的Json檔
            //再把此ID回傳
        return serialNumber.id;
    }


}

package tw.com.xvpower.ch4_20200615_external_file;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import tw.com.xvpower.ch4_20200615_external_file.bean.Order;
import tw.com.xvpower.ch4_20200615_external_file.bean.Product;
import tw.com.xvpower.ch4_20200615_external_file.bean.SerialNumber;
import tw.com.xvpower.ch4_20200615_external_file.data.json.JsonTools;
import tw.com.xvpower.ch4_20200615_external_file.data.json.OrderJsonData;

public class MainActivity extends AppCompatActivity {
    ListView listView = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        File  jsonFileDir = getExternalFilesDir("json");
//        OrderJsonData orderJsonData =
//                OrderJsonData.createOrderJsonData(jsonFileDir);
//        //orderJsonData.deleteAll();
//        List<Order> orderList = orderJsonData.queryOrders();
//        Log.d("Howard","Size:"+orderList.size());

        listView =  findViewById(R.id.ordListView);
        View emptyView =  findViewById(R.id.my_empty_view);
        listView.setEmptyView(emptyView);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
            switch(item.getItemId()){
                case R.id.insert_order:
                    Intent toActivity = new Intent(this,UpdateOrderActivity.class);
                    startActivity(toActivity);
                    break;
            }

        return super.onOptionsItemSelected(item);
    }
}
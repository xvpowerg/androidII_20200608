package tw.com.xvpower.ch18_1_playmusic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
private Mp3Receiver  mp3Receiver;

    private void sendAction(String action){
        Intent actionIntent = new Intent(action);
        sendBroadcast(actionIntent);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button playBtn =   findViewById(R.id.playBtn);
        Button pauseBtn =    findViewById(R.id.pauseBtn);
        Button stopBtn = findViewById(R.id.stopBtn);
        playBtn.setOnClickListener(v->sendAction(Mp3Receiver.PLAY_MUSIC_ACTION));
        pauseBtn.setOnClickListener(v->sendAction(Mp3Receiver.PAUSE_MUSIC_ACTION));
        stopBtn.setOnClickListener(v->sendAction(Mp3Receiver.STOP_MUSIC_ACTION));
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter mp3Filter = new IntentFilter();
        mp3Filter.addAction(Mp3Receiver.PAUSE_MUSIC_ACTION);
        mp3Filter.addAction(Mp3Receiver.PLAY_MUSIC_ACTION);
        mp3Filter.addAction(Mp3Receiver.STOP_MUSIC_ACTION);
        if (mp3Receiver == null){
            mp3Receiver = new Mp3Receiver();
            registerReceiver(mp3Receiver,mp3Filter);
        }

    }
}
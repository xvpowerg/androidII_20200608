package tw.com.xvpower.ch18_1_playmusic;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;

public class Mp3Receiver extends BroadcastReceiver {

    public static final String PLAY_MUSIC_ACTION = "mp3_play_action";
    public static final String PAUSE_MUSIC_ACTION = "mp3_pause_action";
    public static final String STOP_MUSIC_ACTION = "mp3_stop_action";
    private MediaPlayer mediaPlayer;
   // https://developer.android.com/reference/android/media/MediaPlayer
    private void playMethod(Context context){
        if (mediaPlayer == null){
            mediaPlayer = MediaPlayer.create(context,R.raw.test);
        }
        mediaPlayer.start();
    }

    private void pauseMethod(){
        mediaPlayer.pause();
    }

    private void stopMethod(){
        mediaPlayer.stop();
        mediaPlayer = null;
    }



    @Override
    public void onReceive(Context context, Intent intent) {
       String action =  intent.getAction();
            switch (action){
                case PLAY_MUSIC_ACTION:
                    playMethod(context);
                    break;
                case PAUSE_MUSIC_ACTION:
                    pauseMethod();
                    break;
                case STOP_MUSIC_ACTION:
                    stopMethod();
                    break;

            }

    }
}

package tw.com.xvpower.ch17_test_youtub_api;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;
import com.google.android.youtube.player.YouTubeThumbnailLoader;
import com.google.android.youtube.player.YouTubeThumbnailView;

public class MainActivity extends YouTubeBaseActivity {

    private String vid = "QDYfEBY9NM4";
    private YouTubePlayer youTubePlayer;
    private class YouTubeInitListener implements YouTubePlayer.OnInitializedListener {

        @Override
        public void onInitializationSuccess(YouTubePlayer.Provider provider,
                                            YouTubePlayer youTubePlayer, boolean b) {
            Log.d("Howard","b:"+b);
            if (!b)
            youTubePlayer.cueVideo(vid);
            MainActivity.this.youTubePlayer = youTubePlayer;
            Log.d("Howard","onInitializationSuccess!!");
        }

        @Override
        public void onInitializationFailure(YouTubePlayer.Provider provider,
                                            YouTubeInitializationResult youTubeInitializationResult) {
            Log.d("Howard","onInitializationFailure!!");
        }
    }

    private class YoutubeThumbnailInitListener implements YouTubeThumbnailView.OnInitializedListener{

        @Override
        public void onInitializationSuccess(YouTubeThumbnailView youTubeThumbnailView,
                                            YouTubeThumbnailLoader youTubeThumbnailLoader) {
            youTubeThumbnailLoader.setVideo(vid);
            Log.d("Howard","Thumbnail Success");
        }

        @Override
        public void onInitializationFailure(YouTubeThumbnailView youTubeThumbnailView, YouTubeInitializationResult youTubeInitializationResult) {
            Log.d("Howard","Thumbnail Failure");
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String  apiKey =  getString(R.string.API_KEY);
       YouTubeThumbnailView ytv =  findViewById(R.id.youtube_thumbnail);
        YoutubeThumbnailInitListener youtubeThumbnailInitListener =
                        new YoutubeThumbnailInitListener();
        ytv.initialize(apiKey,youtubeThumbnailInitListener);
        ytv.setOnClickListener(v->{
            String msg = "Play";
            if (youTubePlayer.isPlaying()){
                youTubePlayer.pause();
                msg = "Pause";
            }else{
                youTubePlayer.play();
            }
            Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();

        });

        YouTubePlayerView pv = findViewById(R.id.youtube_view);
        YouTubeInitListener yin = new YouTubeInitListener();
        pv.initialize(apiKey,yin);
    }
}
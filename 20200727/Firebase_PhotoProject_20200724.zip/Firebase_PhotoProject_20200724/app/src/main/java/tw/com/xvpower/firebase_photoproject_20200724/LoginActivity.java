package tw.com.xvpower.firebase_photoproject_20200724;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
    private EditText loginEmailText;
    private EditText loginPassText;
    private Button loginBtn;
    private Button regBtn;
    private FirebaseAuth mAuth;
    private void toMainPage(){
        Intent mainIntent = new Intent(this,MainActivity.class);
        startActivity(mainIntent);
        finish();
    }
        private void init(){
            mAuth = FirebaseAuth.getInstance();
            loginEmailText = findViewById(R.id.accountTxt);
            loginPassText = findViewById(R.id.passText1);
            loginBtn = findViewById(R.id.lgoin_btn);
            regBtn = findViewById(R.id.reg_btn);
        }
        private void completeListener(Task<AuthResult> task){
                if (task.isSuccessful()){
                    toMainPage();
                }else{
                    Log.w("Howard",
                            getString(R.string.app_login_fail_msg)+
                                    task.getException().toString());
                    Toast.makeText(this,
                            R.string.app_login_fail_msg, Toast.LENGTH_SHORT).show();
                }
        }
        private void loginAction(View view){
              String email =  loginEmailText.getText().toString();
              String pass =  loginPassText.getText().toString();
              if (!TextUtils.isEmpty(email) && !TextUtils.isEmpty(pass)){
                  mAuth.signInWithEmailAndPassword(email,pass).
                          addOnCompleteListener(this::completeListener);
              }else{
                  Toast.makeText(this,
                          R.string.app_not_empty_msg,Toast.LENGTH_SHORT).show();
              }
        }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        init();
        loginBtn.setOnClickListener(this::loginAction);
        regBtn.setOnClickListener(v->{
            Intent toRegIntent = new Intent(this,RegisterActivity.class);
            startActivity(toRegIntent);
            finish();
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        //如果目前為已登入狀態轉換到MainActivity
        if (mAuth.getCurrentUser() != null){
            toMainPage();
        }
    }
}
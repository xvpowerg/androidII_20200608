package tw.com.xvpower.sqliteproject;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;

import java.util.ArrayList;
import java.util.List;

import tw.com.xvpower.sqliteproject.adapter.StudentAdapter;
import tw.com.xvpower.sqliteproject.databinding.ActivityListBinding;
import tw.com.xvpower.sqliteproject.model.data.Student;
import tw.com.xvpower.sqliteproject.view.MyObserver;
import tw.com.xvpower.sqliteproject.view.StudentViewModel;

public class ListActivity extends AppCompatActivity {
    private ActivityListBinding ab;
    private StudentAdapter stAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ab = ActivityListBinding.inflate(getLayoutInflater());
        setContentView(ab.getRoot());
        Toolbar toolbar = ab.toolbar;
        setSupportActionBar(toolbar);
        List<Student> stList = new ArrayList<>();

        MyObserver<List<Student>> mobs = (list)->{
            stAdapter = new StudentAdapter(this,list);
            ab.rcView.setAdapter(stAdapter);
        };
        StudentViewModel studentViewModel = new StudentViewModel(mobs);
        studentViewModel.refresh();
    }
}
package tw.com.xvpower.sqliteproject.view;

public interface MyObserver<T> {
    void observer(T t);
}

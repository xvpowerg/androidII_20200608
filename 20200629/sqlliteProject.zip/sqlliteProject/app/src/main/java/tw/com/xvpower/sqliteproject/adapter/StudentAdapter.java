package tw.com.xvpower.sqliteproject.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import tw.com.xvpower.sqliteproject.R;
import tw.com.xvpower.sqliteproject.databinding.RcViewLayoutBinding;
import tw.com.xvpower.sqliteproject.model.data.Student;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.MyViewHolder> {
    private Context context;
    private List<Student> stList;
    public StudentAdapter(Context context,List<Student> stList){
        this.context = context;
        this.stList = stList;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RcViewLayoutBinding rcv =
                RcViewLayoutBinding.inflate(LayoutInflater.from(context));
        MyViewHolder  myViewHolder = new MyViewHolder(rcv);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Student st = stList.get(position);
        holder.rcv.nameText.setText(st.getName());
        holder.rcv.scoreText.setText(String.valueOf(st.getScore()));
    }

    @Override
    public int getItemCount() {
        return stList.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder {
        RcViewLayoutBinding rcv;
        public MyViewHolder(@NonNull RcViewLayoutBinding rcv) {
            super(rcv.getRoot());
        }
    }
}

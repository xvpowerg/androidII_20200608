package tw.com.xvpower.sqliteproject.view;

import java.util.List;

import tw.com.xvpower.sqliteproject.model.data.Student;

//ViewModel 內做作一些修改
//目的 資料庫 跟 Activity完全脫離
public class StudentViewModel {
        private  MyLiveData<List<Student>> listLiveData;
      public  StudentViewModel(MyObserver<List<Student>> myObs){
                listLiveData = new MyLiveData();
                listLiveData.setMyObserver(myObs);
        }

        public  void refresh(){
            //listLiveData.setValue();
        }
}

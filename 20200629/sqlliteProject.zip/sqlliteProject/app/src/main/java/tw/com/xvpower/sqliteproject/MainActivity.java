package tw.com.xvpower.sqliteproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import java.util.List;

import tw.com.xvpower.sqliteproject.model.StudentDao;
import tw.com.xvpower.sqliteproject.model.data.Student;
import tw.com.xvpower.sqliteproject.sqlite.DBHelper;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StudentDao sdao = DBHelper.getStudentDao(this);
//        Student st1 = new  Student("Ken",98.5f);
//        sdao.insert(st1);
        List<Student> stList = sdao.queryAll();
        Log.d("Howard","stList:"+stList.size());

    }
}
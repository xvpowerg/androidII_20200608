package tw.com.xvpower.ch15_2_jobscheduler2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
      private JobScheduler jobScheduler;
      public static int JOB_ID = 5678911;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button startJobBtn =  findViewById(R.id.startJobBtn);
        jobScheduler = (JobScheduler) getSystemService(Context.JOB_SCHEDULER_SERVICE);
        startJobBtn.setOnClickListener(v->{
            ComponentName cpm = new ComponentName(getPackageName(),
                    MyJobService.class.getName());
            JobInfo.Builder builder = new  JobInfo.Builder(JOB_ID,cpm);
            builder.setMinimumLatency(3000);
            builder.setOverrideDeadline(10 * 60 * 1000);
             builder.setBackoffCriteria(0,
                  JobInfo.BACKOFF_POLICY_LINEAR);
            JobInfo jobInfo =builder.build();

           if (jobScheduler.schedule(jobInfo) <= 0 ){
               Log.d("Howard","Fail");
           }
        });

        Button stopBtn =   findViewById(R.id.stopJobBtn);
        stopBtn.setOnClickListener(v->{
            jobScheduler.cancel(JOB_ID);
        });
    }
}
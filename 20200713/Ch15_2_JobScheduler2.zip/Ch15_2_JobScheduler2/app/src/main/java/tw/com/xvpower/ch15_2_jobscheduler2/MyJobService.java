package tw.com.xvpower.ch15_2_jobscheduler2;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.util.Log;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

public class MyJobService extends JobService {

    private class MyRun implements  Runnable{
        private JobParameters jobParameters;
            public MyRun(JobParameters jobParameters){
                this.jobParameters = jobParameters;
            }

        @Override
        public void run() {
            int n = ThreadLocalRandom.current().nextInt(5000);
            try { TimeUnit.SECONDS.sleep(1); }
            catch (InterruptedException e) { }
            Log.d("Howard","n:"+n);
            //如果傳入false不會 重複執行
            //如果傳入true會 重複執行 但會受到setBackoffCriteria的影響
            jobFinished(jobParameters,true);
        }
    }

    @Override
    public boolean onStartJob(JobParameters params) {

        Log.d("Howard","onStartJob!!");
        //return false 簡單的工作 不須開新Thread
        //return false 需要開Thread 而且要自行呼叫jobFinished
        MyRun myRun = new MyRun(params);
        Thread th1 = new  Thread(myRun);
        th1.start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        Log.d("Howard","onStopJob");
        return false;
    }
}

package tw.com.xvpower.ch15_3_borodcast_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private MyReceiver r1 = new MyReceiver();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        IntentFilter filter2 = new IntentFilter();
        filter2.addAction("tw.com.action.play");
        registerReceiver(r1,filter2);

        Button btn =  findViewById(R.id.sendMsgeBtn);
        btn.setOnClickListener(v->{
            Intent toBroadcast = new Intent("tw.com.action.play");
            sendBroadcast(toBroadcast);
        });
    }


}
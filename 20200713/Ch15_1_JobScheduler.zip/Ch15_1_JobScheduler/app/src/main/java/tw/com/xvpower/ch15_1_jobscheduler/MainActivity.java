package tw.com.xvpower.ch15_1_jobscheduler;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.KeyEventDispatcher;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private  JobScheduler jobScheduler;
    private static int JOB_ID = 12345678;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         Button startJobBtn = findViewById(R.id.startJobBtn);
        jobScheduler =
                (JobScheduler) getSystemService(Context.JOB_SCHEDULER_SERVICE);
        startJobBtn.setOnClickListener(v->{
            ComponentName compn = new ComponentName(getPackageName(),
                    MyJobService.class.getName());
            JobInfo.Builder builder = new JobInfo.Builder(JOB_ID,compn);
           // builder.setPersisted() //關機之後條件是否保留
            //最短15分鐘 重複一次 如果時間短於15分鐘系統會設定為15分鐘
            //下面寫法20分鐘 重複一次
            // builder.setPeriodic(20 *60 * 1000);
             //不能與Periodic()同時呼叫
            //延遲n毫秒執行
            //builder.setMinimumLatency(3000);
            //電量不能低的時候不執行
            //builder.setRequiresBatteryNotLow()
            //有網路的情況下才執行
            //builder.setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY);
            //當Andorid在休眠情況下執行
            //builder.setRequiresDeviceIdle(true);
            //充電時執行
           // builder.setRequiresCharging(true);
            //重試策略 BACKOFF_POLICY_LINEAR 失敗次數越多重試時就越久
//            builder.setBackoffCriteria(JobInfo.DEFAULT_INITIAL_BACKOFF_MILLIS,
//                    JobInfo.BACKOFF_POLICY_LINEAR);
            JobInfo jobInfo =  builder.build();
             if (jobScheduler.schedule(jobInfo) <= 0){
                 Log.d("Howard","jobScheduler Fail!!");
             }
        });
    }
}
package tw.com.xvpower.ch15_1_jobscheduler;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.util.Log;

public class MyJobService extends JobService {
    @Override
    public boolean onStartJob(JobParameters params) {
        Log.d("Howard","onStartJob!!");
        return false;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        Log.d("Howard","onStopJob!!");
        //true 會依重試策略 做重試
        //false 如果Job有錯不會重試 會立刻停止目前的Job
        return false;
    }
}

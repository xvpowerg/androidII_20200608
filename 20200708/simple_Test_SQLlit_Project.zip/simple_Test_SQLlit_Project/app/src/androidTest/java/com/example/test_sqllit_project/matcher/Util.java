package com.example.test_sqllit_project.matcher;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;
import androidx.test.espresso.matcher.BoundedMatcher;

import org.hamcrest.Description;
import org.hamcrest.Matcher;


public class Util {
    public static Matcher<View> hasItem(Matcher<View> matcher){
        return new BoundedMatcher<View, RecyclerView>(RecyclerView.class) {
            @Override
            public void describeTo(Description description) {
                description.appendText("has Item");
                matcher.describeTo(description);
            }
            @Override
            protected boolean matchesSafely(RecyclerView item) {
                RecyclerView.Adapter adapter = item.getAdapter();
                for (int i =0; i < adapter.getItemCount();i++){
                    int type = adapter.getItemViewType(i);
                  RecyclerView.ViewHolder holder =
                          adapter.createViewHolder(item,type);
                    adapter.onBindViewHolder(holder,i);

                    if (matcher.matches(holder.itemView)){
                               return true;
                    }
                }
                return false;
            }
        };
    }

}

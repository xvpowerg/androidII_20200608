package com.example.test_sqllit_project;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.hamcrest.Matcher;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import java.util.Random;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.clearText;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.longClick;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.contrib.RecyclerViewActions.actionOnItem;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.hasSibling;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static com.example.test_sqllit_project.matcher.Util.hasItem;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.not;


@RunWith(AndroidJUnit4.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestUI {
    static String  testName,testScore,
                updateTestName,updateTestScore ;
    static Matcher m1,m2;
    @Rule
    public ActivityTestRule<MainActivity> activityTestRule =
            new ActivityTestRule<>(MainActivity.class);
    @BeforeClass
    public static void init(){
        Random random = new Random();
        testName = "Ken:"+random.nextInt(50000);
        testScore = random.nextInt(50000)+"";
        updateTestName = "Iris:"+random.nextInt(50000);
        updateTestScore = random.nextInt(50000)+"";
        m1 = allOf(withText(testName),hasSibling(withText(testScore)));
        m2 = allOf(withText(updateTestName),hasSibling(withText(updateTestScore)));
    }
    @Test
    public void aTestInsert(){
          onView(withId(R.id.fab)).perform(click());
          onView(withId(R.id.nameET)).perform(typeText(testName));
          onView(withId(R.id.scoreET)).perform(typeText(testScore));
          onView(withId(android.R.id.button1)).perform(click());
          onView(withId(R.id.rcView)).check(matches(hasItem(hasDescendant(m1))));
      }
    @Test
      public void bTestUpdate() {
        //actionOnItem 方法 RecyclerView專用
        onView(withId(R.id.rcView)).
                perform(actionOnItem(hasDescendant(m1),
                        longClick()));
        onView(withText("Update")).perform(click());
        onView(withId(R.id.nameET)).check(matches(withText(testName)));
        onView(withId(R.id.scoreET)).check(matches(withText(testScore)));
        //清空文字輸入框
        onView(withId(R.id.nameET)).perform(clearText());
        onView(withId(R.id.scoreET)).perform(clearText());
        //填入更新測試數值
        onView(withId(R.id.nameET)).perform(typeText(updateTestName));
        onView(withId(R.id.scoreET)).perform(typeText(updateTestScore));
        onView(withId(android.R.id.button1)).perform(click());
        onView(withId(R.id.rcView)).check(matches(hasItem(hasDescendant(m2))));
    }
    @Test
    public void cTestDelete(){
        onView(withId(R.id.rcView)).
                perform(actionOnItem(hasDescendant(m2),longClick()));
        onView(withText("Delete")).perform(click());
        //not 反向
        onView(withId(R.id.rcView)).check(matches(not(hasItem(hasDescendant(m2)))));
    }
}

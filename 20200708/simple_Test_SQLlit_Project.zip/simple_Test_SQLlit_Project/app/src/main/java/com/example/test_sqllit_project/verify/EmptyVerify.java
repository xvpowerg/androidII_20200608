package com.example.test_sqllit_project.verify;

public class EmptyVerify {
        public static interface  EmetyLinstener{
               public void doing();
        }
        public static boolean testEmpty(String st,EmetyLinstener linstener){
            if (st.trim().isEmpty()){
                if (linstener != null)  linstener.doing();
                return true;
            }
            return false;
        }

}

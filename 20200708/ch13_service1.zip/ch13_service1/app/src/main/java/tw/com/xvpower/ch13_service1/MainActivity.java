package tw.com.xvpower.ch13_service1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import tw.com.xvpower.ch13_service1.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       ActivityMainBinding ab =
               ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(ab.getRoot());
        ab.startBtn.setOnClickListener(v->{
            Intent myIntent = new Intent(this,MyService.class);
            startService(myIntent);
            Log.d("Howard","Start Service!!");
        });

    }
}
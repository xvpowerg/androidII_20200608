package tw.com.xvpower.ch13_service1;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.Date;
import java.util.concurrent.TimeUnit;

public class MyService extends Service {
    private Handler handler = new Handler();
    private Runnable showTime = new Runnable() {
        @Override
        public void run() {
            Log.d("Howard",new Date().toString());
            Log.d("Howard",Thread.currentThread().getName());
            handler.postDelayed(this,1000);
        }
    };

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.d("Howard","onBind");
        return null;
    }

    @Override
    public void onCreate() {
        Log.d("Howard","onCreate");
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("Howard","onStartCommand");
        handler.post(showTime);
//        for (int i = 1;i<=5;i++){
//            Log.d("Howard","s:"+i);
//            try{
//                TimeUnit.SECONDS.sleep(1);
//            }catch(Exception ex){}
//        }
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        Log.d("Howard","onDestroy");
        super.onDestroy();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.d("Howard","onUnbind");
        return super.onUnbind(intent);
    }
}

package tw.com.xvpower.ch1_2_checkboxsp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {
   private ActivityControl ac;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SharedPreferences sp = getSharedPreferences(
                "check_box_sp", Context.MODE_PRIVATE);
        ac = new ActivityControl(this,sp);
        try {
            ac.init();
        } catch (NoSuchFieldException | IllegalAccessException e) {
            Log.e("Howard","Error:"+e);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        ac.display();
    }


}
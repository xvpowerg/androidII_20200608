package tw.com.xvpower.ch1_2_checkboxsp;

import android.content.SharedPreferences;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import java.lang.reflect.Field;
import java.util.stream.Stream;
public class ActivityControl {
    private AppCompatActivity aca;
    private  SharedPreferences sp;
    private Integer[] checkBoxsID = {
        R.id.checkBox0,
        R.id.checkBox1,
        R.id.checkBox2,
        R.id.checkBox3,
        R.id.checkBox4,
        R.id.checkBox5
    };
    private CheckBox[] checkBoxs = new CheckBox[checkBoxsID.length];
    ActivityControl(AppCompatActivity aca, SharedPreferences sp){
        this.aca = aca;
        this.sp = sp;
    }
    private void checkBoxLoop(View view){
       for(CheckBox box : checkBoxs){
            boolean isCheck =  box.isChecked();
           SharedPreferences.Editor edit =  sp.edit();
           edit.putBoolean(String.valueOf(box.getId()),
                   isCheck);
           edit.apply();
       }
    }

//     void init(){
//        //Stream
////         Stream<Integer> chidSt = Stream.of(checkBoxsID);
////         checkBoxs=(CheckBox[])
////                 chidSt.map(aca::findViewById).toArray();
//
//            for (int i =0;i<checkBoxsID.length;i++){
//                checkBoxs[i] = aca.findViewById(checkBoxsID[i]);
//            }
//         Button saveBtn = aca.findViewById(R.id.saveBtn);
//         saveBtn.setOnClickListener(this::checkBoxLoop);
//
//    }

    void init() throws NoSuchFieldException, IllegalAccessException {
        //Stream
//         Stream<Integer> chidSt = Stream.of(checkBoxsID);
//         checkBoxs=(CheckBox[])
//                 chidSt.map(aca::findViewById).toArray();

//

        for (int i = 0 ;i < 6;i++){
            Field field =  R.id.class.getField("checkBox"+i);
            int id = field.getInt(R.id.class);
            checkBoxs[i]  = aca.findViewById(id);
        }

        Button saveBtn = aca.findViewById(R.id.saveBtn);
        saveBtn.setOnClickListener(this::checkBoxLoop);

    }

     void display(){
        for (CheckBox box :checkBoxs){
            if (box == null) continue;
            boolean isCheck= sp.getBoolean(String.valueOf(box.getId()),
                    false);
            box.setChecked(isCheck);
        }
    }


}

package tw.com.xvpower.ch1_testperference;

import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityControl {
    private AppCompatActivity ac;
    private SharedPreferences sp;
    private  EditText accountEdit;
    private EditText passEdit;
    public static final String  SP_ACCOUNT_KEY = "account";
    public static final String  SP_PASSWORD_KEY = "password";
    public static final String  SP_DEF_VALUE= " ";

    ActivityControl(AppCompatActivity ac,SharedPreferences sp){
        this.ac = ac;
        this.sp = sp;
    }

    public void display(){
       String account =  sp.getString(SP_ACCOUNT_KEY,SP_DEF_VALUE);
       String pass = sp.getString(SP_PASSWORD_KEY,SP_DEF_VALUE);
        accountEdit.setText(account);
        passEdit.setText(pass);
    }

    public void init(){
            Button btn =  ac.findViewById(R.id.saveBtn);
             accountEdit = ac.findViewById(R.id.accountEdit);
             passEdit = ac.findViewById(R.id.passEdit);

            btn.setOnClickListener((event)->{
                String accountText =   accountEdit.getText().toString();
                String passwordText = passEdit.getText().toString();
                SharedPreferences.Editor editor =  sp.edit();
                editor.putString(SP_ACCOUNT_KEY,accountText);
                editor.putString(SP_PASSWORD_KEY,passwordText);
                editor.apply();
            });
    }




}

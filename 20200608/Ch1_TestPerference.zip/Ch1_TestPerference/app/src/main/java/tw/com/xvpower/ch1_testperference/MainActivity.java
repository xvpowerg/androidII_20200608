package tw.com.xvpower.ch1_testperference;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private ActivityControl ac;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SharedPreferences sp =
                getSharedPreferences("test_login",
                Context.MODE_PRIVATE);
        ac = new ActivityControl(this,sp);
        ac.init();
    }

    @Override
    protected void onStart() {
        super.onStart();
        ac.display();
    }
}